<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaction_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function log_transaction($data) {
        $this->db->insert('transactions', $data);
        return $this->db->insert_id(); // Mengembalikan ID transaksi yang baru dibuat
    }

    /**
     * [MODIFIKASI]
     * Query ini diubah untuk mengambil 'realm' dari produk yang dibeli.
     */
    private function _get_transactions_with_items() {
        $this->db->select("
            t.*, 
            GROUP_CONCAT(DISTINCT ti.product_name SEPARATOR ', ') as purchased_items,
            MAX(p.realm) as realm 
        "); // <-- 'MAX(p.realm)' ditambahkan
        $this->db->from('transactions as t');
        $this->db->join('transaction_items as ti', 't.id = ti.transaction_id', 'left');
        $this->db->join('products as p', 'ti.product_id = p.id', 'left'); // <-- JOIN ke tabel products ditambahkan
        $this->db->group_by('t.id');
    }

    public function get_all_transactions($days = null) {
        $this->_get_transactions_with_items(); // Fungsi private ini tetap kita gunakan
        
        if ($days) {
            // Tambahkan filter WHERE jika ada parameter hari
            $this->db->where('t.created_at >=', 'CURDATE() - INTERVAL ' . (int)$days . ' DAY', FALSE);
        }

        $this->db->order_by('t.created_at', 'DESC');
        return $this->db->get()->result();
    }

    public function get_recent_transactions($limit = 5) {
        $this->_get_transactions_with_items();
    
        // === TAMBAHKAN BARIS INI UNTUK MEMFILTER HANYA YANG SUDAH BAYAR ===
        $this->db->where('t.status', 'completed');
        // =================================================================
    
        $this->db->order_by('t.created_at', 'DESC');
        $this->db->limit($limit);
        return $this->db->get()->result();
    }

    public function log_transaction_item($data) {
        // Cukup insert data yang diberikan ke tabel 'transaction_items'
        $this->db->insert('transaction_items', $data);
    }

    public function get_transaction_by_id($id) {
        return $this->db->get_where('transactions', ['id' => $id])->row_array();
    }

    // (PERUBAHAN DI SINI)
    // Tambahkan parameter $commission_amount
    public function update_transaction_status($id, $status, $commission_amount = null) {
        $data = ['status' => $status];
        
        // Jika $commission_amount diberikan, tambahkan ke data update
        if ($commission_amount !== null) {
            $data['affiliate_commission_amount'] = $commission_amount;
        }
        
        $this->db->where('id', $id);
        $this->db->update('transactions', $data);
    }

    /**
     * [MODIFIKASI] Fungsi baru untuk menghitung jumlah transaksi SELESAI
     * yang pernah dilakukan oleh seorang pemain.
     * @param string $player_uuid UUID pemain
     * @return int Jumlah transaksi
     */
    public function get_completed_transaction_count($player_uuid) {
        if (empty($player_uuid)) {
            return 0;
        }
        $this->db->where('player_uuid', $player_uuid);
        $this->db->where('status', 'completed');
        return $this->db->count_all_results('transactions');
    }
}
