<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Promo_popup_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    public function get_promo_data()
    {
        // Assuming there is only one row in this table
        $query = $this->db->get('promo_popup_5tier', 1);
        return $query->row_array();
    }

    public function update_promo_data($data)
    {
        // Assuming you're updating the single row. 
        // If you have multiple rows, you might need a WHERE clause.
        return $this->db->update('promo_popup_5tier', $data);
    }
}
