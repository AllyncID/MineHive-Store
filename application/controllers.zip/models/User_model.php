<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
public function validate_user($username, $platform) {
    // Kita gunakan log_message('error', ...) agar pesannya pasti tercatat dan mudah dicari
    log_message('error', '--- DEBUG LOGIN BARU ---');
    log_message('error', 'Step 1: Data diterima dari controller. Username: [' . $username . '], Platform: [' . $platform . ']');

    // Logika untuk menangani prefix '.' pada pemain Bedrock
    if ($platform === 'bedrock') {
        log_message('error', 'Step 2: Terdeteksi sebagai platform Bedrock.');
        if (substr($username, 0, 1) !== '.') {
            $username = '.' . $username;
            log_message('error', 'Step 3: Titik ditambahkan. Username sekarang menjadi: [' . $username . ']');
        } else {
            log_message('error', 'Step 3: Titik TIDAK ditambahkan karena username input sudah diawali titik.');
        }
    } else {
        log_message('error', 'Step 2: Terdeteksi sebagai platform Java. Tidak ada perubahan pada username.');
    }

    // Sambungkan ke database proxy
    $proxy_db = $this->load->database('proxy', TRUE);

    // Cek koneksi ke DB Proxy
    if (!$proxy_db || !$proxy_db->conn_id) {
        log_message('error', 'Step 4 GAGAL: Tidak bisa terhubung ke database "proxy"!');
        return false;
    }

    // Query ke tabel user_profiles
    log_message('error', 'Step 4: Mencari di `user_profiles` dengan LOWER(lastNickname) = [' . strtolower($username) . ']');
    $query = $proxy_db
                ->select('uniqueId as uuid, lastNickname')
                ->from('user_profiles')
                ->where('LOWER(lastNickname)', strtolower($username))
                ->limit(1)
                ->get();

    if ($query->num_rows() == 1) {
        log_message('error', 'Step 5: SUKSES ditemukan di `user_profiles`.');
        $result = $query->row_array();
        $result['username'] = $result['lastNickname']; // Menyamakan format output
        return $result;
    } else {
        log_message('error', 'Step 5: TIDAK ditemukan di `user_profiles`. Mencoba fallback ke LuckPerms lobby...');
        
        // Fallback ke LuckPerms Lobby (jika Anda masih menggunakannya)
        $lobby_db = $this->load->database('lobby', TRUE);
        if (!$lobby_db || !$lobby_db->conn_id) {
            log_message('error', 'Step 6 GAGAL: Tidak bisa terhubung ke database "lobby"!');
            return false;
        }

        log_message('error', 'Step 6: Mencari di `luckperms_players` dengan username = [' . strtolower($username) . ']');
        $query_lobby = $lobby_db->select('uuid, username')->from('luckperms_players')->where('username', strtolower($username))->limit(1)->get();
        
        if ($query_lobby->num_rows() === 1) {
             log_message('error', 'Step 7: SUKSES ditemukan di `luckperms_players`.');
             return $query_lobby->row_array();
        } else {
             log_message('error', 'Step 7: TIDAK ditemukan di mana pun. Login gagal.');
             return false;
        }
    }
}
}