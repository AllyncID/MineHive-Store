<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Memastikan koneksi database dimuat
    }

    /**
     * Mengambil daftar produk dari DATABASE berdasarkan nama realm.
     * @param string $realm_name Nama realm.
     * @return array Daftar produk.
     */
    public function get_products_by_realm($realm_name, $category) { // <-- Nama parameter kedua lebih cocok 'category'
        $this->db->where('realm', $realm_name);
        
        // --- PERUBAHAN DI SINI ---
        // Kita sekarang memfilter berdasarkan kolom 'category' yang baru.
        $this->db->where('category', $category); 
        
        $this->db->where('is_active', 1);
        $query = $this->db->get('products');
        return $query->result_array();
    }

    /**
     * Fungsi untuk mendapatkan satu produk dari DATABASE berdasarkan ID-nya.
     * @param string $product_id ID produk.
     * @return array|null Satu baris data produk atau null.
     */
    public function get_product_by_id($product_id) {
        $query = $this->db->get_where('products', ['id' => $product_id]);
        return $query->row_array(); // Mengembalikan SATU baris sebagai array asosiatif
    }

public function get_player_rank($username, $realm_name, $rank_hierarchy) {
    if (empty($username) || empty($realm_name) || empty($rank_hierarchy)) {
        return null;
    }

    $db_group = strtolower($realm_name);
    try {
        $realm_db = $this->load->database($db_group, TRUE);
        if (!$realm_db || !$realm_db->conn_id) { return null; }
    } catch (Exception $e) {
        log_message('error', 'get_player_rank: ' . $e->getMessage());
        return null;
    }

    // Langkah 1: Dapatkan UUID pemain dari tabel players berdasarkan username huruf kecil
    $player_query = $realm_db->select('uuid')->from('luckperms_players')->where('username', strtolower($username))->limit(1)->get();
    if ($player_query->num_rows() === 0) {
        return null; // Pemain tidak ditemukan di tabel players
    }
    $uuid = $player_query->row()->uuid;

    // Langkah 2: Dapatkan semua grup permanen yang dimiliki pemain dari tabel permissions
    $permissions_query = $realm_db->select('permission')
                                  ->from('luckperms_user_permissions')
                                  ->where('uuid', $uuid)
                                  ->where('permission LIKE', 'group.%') // Cari permission yang merupakan grup
                                  ->where('expiry', 0) // <-- Kunci: Hanya ambil yang permanen (tidak ada waktu kedaluwarsa)
                                  ->get();

    if ($permissions_query->num_rows() === 0) {
        return 'default'; // Jika tidak punya rank, anggap 'default'
    }

    $highest_rank = 'default';
    $highest_weight = $rank_hierarchy['default'] ?? 0;

    // Langkah 3: Loop semua grup dan cari yang bobotnya paling tinggi
    foreach ($permissions_query->result() as $row) {
        $rank_name = str_replace('group.', '', $row->permission);
        
        // Cek apakah rank ini ada di hierarki kita
        if (isset($rank_hierarchy[$rank_name])) {
            $current_weight = $rank_hierarchy[$rank_name];
            // Jika bobot rank saat ini lebih tinggi dari yang sudah disimpan, perbarui
            if ($current_weight > $highest_weight) {
                $highest_weight = $current_weight;
                $highest_rank = $rank_name;
            }
        }
    }

    return $highest_rank;
}
    
public function has_player_joined_realm($username, $realm_name)
{
    // Konversi nama realm menjadi nama grup database
    $db_group = strtolower($realm_name);

    try {
        $realm_db = $this->load->database($db_group, TRUE);
        if (!$realm_db || !$realm_db->conn_id) {
            log_message('error', 'Gagal terhubung ke database realm: ' . $db_group);
            return false;
        }
    } catch (Exception $e) {
        log_message('error', 'Error saat memuat database realm: ' . $e->getMessage());
        return false;
    }
    
    // Jalankan query dengan mengubah username dari session menjadi huruf kecil
    $query = $realm_db->select('uuid')
                      ->from('luckperms_players')
                      ->where('username', strtolower($username)) // <-- Kunci perubahannya di sini
                      ->limit(1)
                      ->get();

    return $query->num_rows() === 1;
}
// public function has_player_joined_realm($uuid, $realm_db_group) {
//         // Selalu anggap pemain sudah pernah join untuk sementara
//         return true; 
//     }

    /**
     * Mengambil daftar top donatur berdasarkan total pembelian.
     * @param int $limit Jumlah donatur yang ingin ditampilkan.
     * @return array Daftar top donatur.
     */
    public function get_top_donators($limit = 5) {
        $this->db->select('player_username, SUM(grand_total) as total_spent');
        $this->db->from('transactions');
        $this->db->where('status', 'completed');
        $this->db->group_by('player_username');
        $this->db->order_by('total_spent', 'DESC');
        $this->db->limit($limit);
        
        $query = $this->db->get();
        return $query->result_array();
    }
    
// GANTI FUNGSI LAMA ANDA DENGAN VERSI BARU INI

public function get_cross_sell_products($cart_items = [], $limit = 2) {
    if (empty($cart_items)) {
        return [];
    }

    $exclude_ids = array_column($cart_items, 'id');
    
    // === PERBAIKAN DI SINI ===
    // Menggunakan fungsi distinct() bawaan CodeIgniter
    $realms_in_cart = $this->db
                           ->distinct()
                           ->select('realm')
                           ->where_in('id', $exclude_ids)
                           ->get('products')
                           ->result_array();

    if (empty($realms_in_cart)) {
        return [];
    }
    
    $realm_names = array_column($realms_in_cart, 'realm');

    // Query utama untuk mencari produk rekomendasi
    $this->db->select('*');
    $this->db->from('products');
    $this->db->where_in('category', ['bundles', 'currency']);
    $this->db->where_in('realm', $realm_names);
    $this->db->where_not_in('id', $exclude_ids);
    $this->db->where('is_active', 1);
    $this->db->order_by('RAND()');
    $this->db->limit($limit);

    $query = $this->db->get();
    return $query->result_array();
}
}