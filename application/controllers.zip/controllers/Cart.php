<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Store_model');
        $this->load->model('Promo_model');
        $this->load->model('Discount_model');
        $this->load->model('Product_model');
        $this->load->model('Cart_discount_model'); 
        $this->load->model('Settings_model');      
        $this->load->model('Affiliate_model');
        $this->load->model('Transaction_model');
        $this->config->load('ranks', TRUE);
        $this->load->helper('url');
        $this->load->library('user_agent');
    }

    private function _get_cart_from_session() {
        return $this->session->userdata('cart') ?? [
            'items' => [],
            'subtotal' => 0,
            'cart_discount' => 0,
            'applied_cart_discount_tier' => null,
            'promo_discount' => 0, // Diskon dari kode promo
            'referral_discount' => 0, // Diskon dari kode referral
            'applied_promo' => null, // Data kode promo
            'applied_referral' => null, // Data kode referral
            'grand_total' => 0
        ];
    }

    /**
     * [BARU v3] Fungsi helper untuk mengecek apakah data adalah list item bundle yang valid
     */
    private function _is_valid_item_list($data) {
        // Cek 1: Apakah ini array?
        if (!is_array($data)) {
            return false;
        }
        // Cek 2: Apakah array ini kosong? (Jika kosong, ini BUKAN list item)
        if (empty($data)) {
            return false;
        }
        // Cek 3: Apakah ini adalah LIST (index 0, 1, 2...)?
        if (array_keys($data) !== range(0, count($data) - 1)) {
            return false; // Ini adalah object/map {"Misc":...}
        }
        // Cek 4: Apakah elemen pertamanya adalah ID (scalar), bukan array/object?
        if (!is_scalar($data[0])) {
            return false; // Ini adalah list of objects/arrays [ {"id":1}, ... ]
        }
        
        // Jika lolos semua, ini adalah list ID [1, 2, 3]
        return true;
    }


    public function index() {
        // --- Data untuk Header (Announcement Bar) ---
        $settings = $this->Settings_model->get_all_settings();
        $data['announcement_bar'] = [
            'enabled'   => $settings['announcement_bar_enabled'] ?? false,
            'text'      => $settings['announcement_bar_text'] ?? '',
            'link'      => $settings['announcement_bar_link'] ?? '',
            'timer_end' => $settings['announcement_timer_end'] ?? ''
        ];

        // === LANGKAH 1: MUAT DATA CART DARI SESSION TERLEBIH DAHULU ===
        $cart = $this->_get_cart_from_session(); // Gunakan helper baru

        // === PENTING: Hitung ulang total setiap kali halaman cart dimuat ===
        $this->_update_cart_totals($cart);
        $this->session->set_userdata('cart', $cart); // Simpan kembali cart yang sudah diupdate
        // ====================================================================

        // === (LOGIKA BARU) MEMBUAT PESAN HASUTAN (UPSELL) ===
        $subtotal = $cart['subtotal'];
        $data['upsell_message'] = null; // Default null
        $data['first_time_buyer_message'] = null; // [MODIFIKASI] Pesan baru

        // Cek dulu apakah dia pembeli pertama
        $uuid = $this->session->userdata('uuid');
        $transaction_count = $this->Transaction_model->get_completed_transaction_count($uuid);
        $data['is_first_time_buyer'] = ($transaction_count == 0);

        if ($data['is_first_time_buyer'] && $subtotal > 0) {
            // [MODIFIKASI] Tampilkan pesan bonus pembelian pertama
            $data['first_time_buyer_message'] = "Ini pembelian pertamamu! Selesaikan checkout untuk mendapatkan <strong>Bonus Spesial</strong> eksklusif!";
        } 
        
        // [MODIFIKASI] Hapus 'else' agar blok ini berjalan terpisah
        if ($subtotal > 0 && $this->Cart_discount_model->is_enabled()) {
            // [MODIFIKASI] Logika upsell diskon keranjang
            $applied_tier = $cart['applied_cart_discount_tier'];
            $next_tier = $this->Cart_discount_model->get_next_tier($subtotal);

            if ($next_tier) {
                $amount_needed = $next_tier->min_amount - $subtotal;
                $percentage = (int) $next_tier->discount_percentage;
                $data['upsell_message'] = "Tambah belanjaan senilai <strong>Rp " . number_format($amount_needed, 0, ',', '.') . "</strong> lagi untuk mendapatkan diskon extra <strong>" . $percentage . "%</strong>!";
            }
        }
        // === AKHIR LOGIKA BARU ===


        $data['cart'] = $cart;


        $data['cross_sell_products'] = [];
        if (!empty($data['cart']['items'])) {
            $raw_cross_sell_products = $this->Store_model->get_cross_sell_products($data['cart']['items']);

            foreach ($raw_cross_sell_products as &$product) { 
                $active_discount = $this->Discount_model->find_active_discount_for_product($product['id'], $product['realm'] ?? $product['category']); 

                if ($active_discount) {
                    $discount_amount = $product['price'] * ($active_discount->discount_percentage / 100);
                    $product['final_price'] = $product['price'] - $discount_amount;
                    $product['original_price'] = $product['price'];
                } else {
                    $product['final_price'] = $product['price'];
                    $product['original_price'] = null;
                }
            }
            unset($product); 

            $data['cross_sell_products'] = $raw_cross_sell_products;
        }

        $data['title'] = 'Cart | Mine Hive';
        $this->load->view('templates/header', $data);
        $this->load->view('cart_view', $data);
        $this->load->view('templates/footer');
    }

    /**
     * [FUNGSI BARU] Menghitung total harga asli dari semua item di dalam bundle.
     *
     * @param array $item_ids Array berisi ID produk di dalam bundle.
     * @return float Total harga asli.
     */
    private function _get_bundle_original_total(array $item_ids) {
        $total = 0;
        foreach ($item_ids as $item_id) {
            if (!is_scalar($item_id)) continue; // Keamanan data

            $product = $this->Store_model->get_product_by_id($item_id);
            if ($product) {
                if ($product['product_type'] === 'bundles') {
                    // Ini nested bundle, panggil rekursif
                    $nested_ids = json_decode($product['description'], true);
                    
                    // [PERBAIKAN v3] Cek menggunakan helper baru
                    if ($this->_is_valid_item_list($nested_ids))
                    {
                        $total += $this->_get_bundle_original_total($nested_ids);
                    } else {
                        // Ini adalah bundle "kosong" atau "perks", hitung harganya sendiri
                        $total += (float)$product['price'];
                    }
                } else {
                    // Ini item biasa, tambahkan harganya
                    $total += (float)$product['price'];
                }
            }
        }
        return $total;
    }

    /**
     * [MODIFIKASI BESAR] Fungsi _add_item_to_cart sekarang menerima nama bundle dan rasio diskon.
     *
     * @param int $product_id ID produk.
     * @param string $source_category Kategori (untuk upgrade).
     * @param array &$cart Referensi keranjang.
     * @param string|null $parent_bundle_name Nama bundle induk (untuk akhiran nama).
     * @param float $bundle_ratio Rasio diskon bundle (0.0 - 1.0).
     * @param int|null $parent_bundle_id [BARU] ID dari bundle induk untuk grouping.
     * @param bool $is_flash_sale [BARU] Tandai jika ini dari flash sale.
     * @return array Status.
     */
    private function _add_item_to_cart($product_id, $source_category = 'ranks', &$cart, $parent_bundle_name = null, $bundle_ratio = 1.0, $parent_bundle_id = null, $is_flash_sale = false) {
        $product_to_add = $this->Store_model->get_product_by_id($product_id);
        if (!$product_to_add) {
            return ['status' => 'error', 'message' => 'Produk tidak ditemukan.'];
        }

        // --- [LOGIKA REKURSIF UNTUK NESTED BUNDLE] ---
        if ($product_to_add['product_type'] === 'bundles') {
            $product_ids_in_bundle = json_decode($product_to_add['description'], true);

            // [PERBAIKAN LOGIKA v3] Cek menggunakan helper baru
            if ($this->_is_valid_item_list($product_ids_in_bundle))
            {
                
                $item_added_count = 0;
                foreach ($product_ids_in_bundle as $item_id_in_bundle) {
                    // Teruskan pemanggilan rekursif dengan MEMBAWA nama bundle induk dan rasionya
                    $result = $this->_add_item_to_cart($item_id_in_bundle, 'ranks', $cart, $parent_bundle_name, $bundle_ratio, $parent_bundle_id, $is_flash_sale);
                    if ($result['status'] == 'success') {
                        $item_added_count++;
                    }
                }
                
                // Setelah membongkar, KEMBALI. Jangan tambahkan bundle "pembungkus"nya.
                if ($item_added_count > 0) {
                     return ['status' => 'success', 'message' => 'Isi dari sub-bundle "' . $product_to_add['name'] . '" ditambahkan.'];
                } else {
                     return ['status' => 'info', 'message' => 'Item dari sub-bundle "' . $product_to_add['name'] . '" sudah ada di keranjang.'];
                }
            }
            // JIKA BUNDLE INI KOSONG (seperti Battlepass),
            // kita sengaja "jatuh" (fall-through) ke logika penambahan item di bawah.
        }
        // --- [AKHIR LOGIKA REKURSIF] ---

        // Jika produk sudah ada di keranjang, kita tidak bisa menambahkannya lagi
        // (Bahkan jika dari bundle berbeda, untuk menghindari konflik harga)
        if (isset($cart['items'][$product_id])) {
            return ['status' => 'info', 'message' => 'Produk "' . $product_to_add['name'] . '" sudah ada di keranjang.'];
        }

        $item_name = $product_to_add['name'];
        $final_item_price = (float) $product_to_add['price'];
        $original_price_for_display = null;
        $is_upgrade = false;

        // Tambahkan (Realm) jika perlu
        if ($product_to_add['category'] === 'currency') { 
            $item_name .= ' (' . ucfirst($product_to_add['realm']) . ')';
        }

        // [BARU] Tambahkan (Flash Sale) jika dari flash sale
        if ($is_flash_sale) {
            $item_name .= ' (Flash Sale)';
        }

        // --- [MODIFIKASI] Logika Upgrade TIDAK BISA DARI BUNDLE ---
        // Kita anggap item di dalam bundle BUKAN upgrade
        if ($source_category == 'rank_upgrades' && $product_to_add['category'] == 'ranks' && $bundle_ratio == 1.0) {
            $is_upgrade = true;
            // ... (logika upgrade tidak berubah) ...
            $item_name = $product_to_add['name'] . ' (Upgrade)';
            $username = $this->session->userdata('username');
            $realm = $product_to_add['realm'];
            $all_hierarchies = $this->config->item('rank_hierarchies', 'ranks');
            $hierarchy = $all_hierarchies[strtolower($realm)] ?? [];
            $current_rank_name = $this->Store_model->get_player_rank($username, $realm, $hierarchy);
            $player_rank_weight = $hierarchy[$current_rank_name] ?? 0;
            $target_rank_weight = $hierarchy[$product_to_add['luckperms_group']] ?? 0;
            if ($target_rank_weight > $player_rank_weight) {
                $current_rank_product = $this->Product_model->get_product_by_luckperms_group($current_rank_name, $realm);
                if ($current_rank_product) {
                    $upgrade_cost = $product_to_add['price'] - $current_rank_product->price;
                    $final_item_price = max(0, $upgrade_cost);
                    $original_price_for_display = $product_to_add['price'];
                }
            } else {
                 return ['status' => 'error', 'message' => 'Anda tidak bisa meng-upgrade ke rank yang setara atau lebih rendah.'];
            }
        }
        
        // --- Kalkulasi Diskon Item (cth: diskon Lebaran) ---
        $active_discount = $this->Discount_model->find_active_discount_for_product($product_to_add['id'], $product_to_add['category']);
        if ($active_discount) {
            if (is_null($original_price_for_display)) {
                $original_price_for_display = $final_item_price;
            }
            $discount_amount = $final_item_price * ($active_discount->discount_percentage / 100);
            $final_item_price -= $discount_amount;
        }

        // --- [MODIFIKASI BARU] ---
        
        // 1. Tetapkan harga 'asli' (setelah diskon item/upgrade) SEBELUM dikali rasio bundle
        // Jika $original_price_for_display masih kosong, gunakan harga final
        if (is_null($original_price_for_display)) {
            $original_price_for_display = $final_item_price;
        }

        // 2. Terapkan rasio diskon bundle
        $final_item_price = $final_item_price * $bundle_ratio;

        // 3. Tambahkan akhiran nama bundle
        if ($parent_bundle_name) {
            // [FIX BUG &#039;] Hapus html_escape() dari sini
            $item_name .= ' [' . $parent_bundle_name . ']';
        }
        // --- [AKHIR MODIFIKASI BARU] ---


        $cart_item = [
            'id'             => $product_to_add['id'],
            'name'           => $item_name,
            'price'          => $final_item_price, // Harga yang sudah dikali rasio
            'is_upgrade'     => $is_upgrade,
            'original_price' => ($bundle_ratio < 1.0 || $is_flash_sale) ? $original_price_for_display : null, // Tampilkan harga coret jika ada diskon bundle ATAU flash sale
            'is_flash_sale'  => $is_flash_sale, // [MODIFIKASI] Simpan status flash sale
            'bundle_group_id' => $parent_bundle_id // [BARU] Simpan ID group bundle
        ];
        $cart['items'][$product_id] = $cart_item;

        // [FIX BUG &#039;] Hapus html_escape() dari pesan sukses
        return ['status' => 'success', 'message' => 'Produk "' . $item_name . '" berhasil ditambahkan ke keranjang!'];
    }


    /**
     * [MODIFIKASI BESAR] Fungsi add() sekarang menangani logika harga bundle.
     */
    public function add($product_id = NULL, $source_category = 'ranks') {
        if (!$product_id) { redirect(base_url()); return; }

        if (!$this->session->userdata('is_logged_in')) {
            $this->session->set_flashdata('error', 'Anda harus login untuk menambahkan item.');
            redirect($this->agent->referrer() ?? 'cart');
            return;
        }

        $cart = $this->_get_cart_from_session();
        $product_to_add = $this->Store_model->get_product_by_id($product_id);

        if (!$product_to_add) {
             $this->session->set_flashdata('error', 'Produk tidak valid.');
             redirect(base_url()); 
             return;
        }

        $bundle_data = json_decode($product_to_add['description'], true);

        // --- [LOGIKA BARU V3] ---
        // Cek apakah produk ini adalah bundle DAN merupakan list item yang valid
        if ($product_to_add['product_type'] === 'bundles' && $this->_is_valid_item_list($bundle_data)) {
            
            // Ini adalah BUNDLE DENGAN ISI. Bongkar...
            $product_ids_in_bundle = $bundle_data;
            
            // 1. Dapatkan harga "master" bundle
            $master_bundle_price = (float)$product_to_add['price'];
            
            // 2. Dapatkan nama bundle
            $parent_bundle_name = $product_to_add['name'];
            
            // [BARU] Dapatkan ID bundle induk (kita pakai ID produk bundle-nya)
            $parent_bundle_id = $product_to_add['id'];

            // 3. Hitung total harga asli semua item di dalamnya (secara rekursif)
            $original_total_price = $this->_get_bundle_original_total($product_ids_in_bundle);

            // 4. Hitung rasio diskon
            $bundle_ratio = 1.0;
            if ($original_total_price > 0 && $master_bundle_price < $original_total_price) {
                $bundle_ratio = $master_bundle_price / $original_total_price;
            }

            $items_added_count = 0;
            $items_info_count = 0;
            $items_error_count = 0;

            // 5. Loop dan tambahkan item dengan membawa rasio & nama bundle
            foreach ($product_ids_in_bundle as $item_id_in_bundle) {
                if (is_scalar($item_id_in_bundle)) {
                    // [MODIFIKASI] Kirim $parent_bundle_id, $is_flash_sale (false)
                    $result = $this->_add_item_to_cart($item_id_in_bundle, 'ranks', $cart, $parent_bundle_name, $bundle_ratio, $parent_bundle_id, false);
                    
                    if ($result['status'] == 'success') {
                        $items_added_count++;
                    } elseif ($result['status'] == 'info') {
                        $items_info_count++;
                    } else {
                        $items_error_count++;
                    }
                } else {
                    log_message('error', 'Cart Error: add function call skipped invalid data. Bundle ID: ' . $product_id);
                    $items_error_count++;
                }
            }

            // [FIX BUG &#039;] Hapus html_escape() dari pesan sukses
            if ($items_added_count > 0) {
                $this->session->set_flashdata('success', 'Paket "' . $parent_bundle_name . '" (' . $items_added_count . ' item) berhasil ditambahkan ke keranjang!');
            } elseif ($items_info_count > 0 && $items_added_count == 0) {
                 $this->session->set_flashdata('info', 'Semua item dari paket "' . $parent_bundle_name . '" sudah ada di keranjang Anda.');
            } elseif ($items_error_count > 0 && $items_added_count == 0 && $items_info_count == 0) {
                 $this->session->set_flashdata('error', 'Tidak ada item yang bisa ditambahkan dari paket bundle ini.');
            }

        } else {
            // Ini produk TUNGGAL, ATAU bundle "kosong" (command-only).
            // Panggil helper (rasio 1.0, tanpa nama bundle, tanpa grup)
            $result = $this->_add_item_to_cart($product_id, $source_category, $cart, null, 1.0, null, false);

            // Set flashdata berdasarkan hasil dari _add_item_to_cart
            if ($result['status'] == 'success') {
                $this->session->set_flashdata('success', $result['message']);
            } elseif ($result['status'] == 'info') {
                $this->session->set_flashdata('info', $result['message']);
            } else {
                $this->session->set_flashdata('error', $result['message']);
                redirect($this->agent->referrer() ?? 'cart');
                return;
            }
        }

        $this->_update_cart_totals($cart);
        $this->session->set_userdata('cart', $cart);
        redirect('cart');
    }


    public function remove($product_id) {
        $cart = $this->_get_cart_from_session(); 
        
        if (isset($cart['items'][$product_id])) {
            
            // [LOGIKA BARU ANTI-ABUSE]
            // Cek apakah item yang dihapus adalah bagian dari bundle
            $bundle_group_to_remove = $cart['items'][$product_id]['bundle_group_id'] ?? null;
            
            if ($bundle_group_to_remove !== null) {
                // Ya, ini bagian dari bundle. Hapus semua item lain dari bundle yang sama.
                $new_cart_items = [];
                foreach ($cart['items'] as $id => $item) {
                    // Simpan item JIKA item tsb BUKAN bagian dari bundle group yang dihapus
                    if (($item['bundle_group_id'] ?? null) != $bundle_group_to_remove) {
                        $new_cart_items[$id] = $item;
                    }
                }
                $cart['items'] = $new_cart_items; // Ganti cart lama dengan cart yang sudah difilter
                $this->session->set_flashdata('info', 'Item bundle dihapus. Semua item dari paket yang sama juga ikut dihapus.');
                
            } else {
                // Bukan bagian dari bundle, hapus satu item saja (logika lama)
                unset($cart['items'][$product_id]);
                $this->session->set_flashdata('info', 'Produk telah dihapus dari keranjang.');
            }
            // [AKHIR LOGIKA ANTI-ABUSE]


            if (empty($cart['items'])) {
                $cart['applied_promo'] = null;
                $cart['applied_referral'] = null;
            }

            $this->_update_cart_totals($cart); 
            $this->session->set_userdata('cart', $cart);
            // [PERBAIKAN] Hapus flashdata duplikat
        }
        redirect('cart');
    }

    public function apply_promo() {
        header('Content-Type: application/json');
        
        $cart = $this->_get_cart_from_session();
        if (empty($cart['items'])) {
            echo json_encode(['status' => 'error', 'message' => 'Keranjang Anda kosong.']);
            return;
        }

        $input_code = strtoupper($this->input->post('promo_code'));
        $response = [];

        $promo_data = $this->Promo_model->get_by_code($input_code);
        $affiliate_code_data = $this->Affiliate_model->get_code_by_string($input_code);

        if ($promo_data) {
            // --- INI ADALAH KODE PROMO ---
            $usage_count = $promo_data->usage_count ?? 0;
            
            // [PERBAIKAN] Hapus pengecekan 'is_active' yang tidak ada
            if ($promo_data->expires_at && strtotime($promo_data->expires_at) < time()) {
                $response = ['status' => 'error', 'message' => 'Kode promo tersebut sudah kedaluwarsa.'];
            } elseif ($promo_data->usage_limit !== null && $usage_count >= $promo_data->usage_limit) {
                $response = ['status' => 'error', 'message' => 'Batas pemakaian kode promo ini sudah habis.'];
            } else {
                // Kode promo valid. Cek aturan stacking
                // [PERBAIKAN] Gunakan empty() untuk cek 'allow_stacking' dengan aman
                $allow_stacking = !empty($promo_data->allow_stacking); // Cek apakah allow_stacking = 1
                
                if (isset($cart['applied_referral']) && !$allow_stacking) {
                    // Ada referral, dan promo ini TIDAK mengizinkan stacking
                    $response = ['status' => 'error', 'message' => 'Kode promo ini tidak bisa digabung dengan kode referral yang sudah ada.'];
                } else {
                    // Aman, terapkan kode promo
                    $cart['applied_promo'] = [
                        'type' => 'promo',
                        'code' => $promo_data->code,
                        'discount_type' => $promo_data->type,
                        'value' => $promo_data->value,
                        'allow_stacking' => $allow_stacking // Simpan nilai boolean
                    ];
                    $response = ['status' => 'success', 'message' => 'Kode promo berhasil digunakan!'];
                }
            }

        } elseif ($affiliate_code_data) {
            // --- INI ADALAH KODE REFERRAL ---
            
            // Cek aturan stacking
            // [PERBAIKAN] Gunakan empty() untuk cek 'allow_stacking' di keranjang dengan aman
            $promo_is_stackable = !empty($cart['applied_promo']['allow_stacking']);

            if (isset($cart['applied_promo']) && !$promo_is_stackable) {
                // Ada promo, dan promo itu TIDAK mengizinkan stacking
                $response = ['status' => 'error', 'message' => 'Kode referral ini tidak bisa digabung dengan kode promo yang sudah ada.'];
            } else {
                // Aman, terapkan kode referral
                $cart['applied_referral'] = [
                    'type' => 'affiliate',
                    'code' => $affiliate_code_data->code,
                    'discount_type' => 'percentage', // Referral selalu percentage
                    'value' => $affiliate_code_data->customer_discount_percentage / 100,
                    'affiliate_id' => $affiliate_code_data->affiliate_id
                ];
                $response = ['status' => 'success', 'message' => 'Kode referral berhasil digunakan!'];
            }

        } else {
            // --- KODE TIDAK DITEMUKAN ---
            $response = ['status' => 'error', 'message' => 'Kode yang Anda masukkan tidak valid.'];
        }

        // Hitung ulang total dan simpan ke session
        $this->_update_cart_totals($cart);
        $this->session->set_userdata('cart', $cart);

        // Kirim data cart baru ke JavaScript
        $response['cart'] = [
            'subtotal' => 'Rp ' . number_format($cart['subtotal'], 0, ',', '.'),
            'cart_discount' => '- Rp ' . number_format($cart['cart_discount'], 0, ',', '.'),
            'cart_discount_percentage' => (isset($cart['applied_cart_discount_tier']) ? (int) $cart['applied_cart_discount_tier']['percentage'] : 0),
            'promo_discount' => '- Rp ' . number_format($cart['promo_discount'], 0, ',', '.'),
            'referral_discount' => '- Rp ' . number_format($cart['referral_discount'], 0, ',', '.'),
            'grand_total' => 'Rp ' . number_format($cart['grand_total'], 0, ',', '.'),
            'applied_promo_data' => $cart['applied_promo'] ?? null,
            'applied_referral_data' => $cart['applied_referral'] ?? null
        ];

        echo json_encode($response);
        return;
    }


    /**
     * Menghitung ulang semua total di keranjang.
     *
     * @param array &$cart The cart data array (passed by reference).
     */
    private function _update_cart_totals(&$cart) {
        $subtotal = 0;
        $subtotal_excluding_flash_sale = 0;
        $cart_discount_amount = 0;

        // 1. Hitung subtotal
        foreach ($cart['items'] as $item) {
            $subtotal += $item['price'];
            if (empty($item['is_flash_sale'])) {
                $subtotal_excluding_flash_sale += $item['price'];
            }
        }
        $cart['subtotal'] = $subtotal;

        // Reset diskon
        $cart['cart_discount'] = 0;
        $cart['applied_cart_discount_tier'] = null;
        $cart['promo_discount'] = 0;
        $cart['referral_discount'] = 0;

        // 2. Hitung Diskon Keranjang (Tier)
        $settings = $this->Settings_model->get_all_settings();
        $is_cart_discount_enabled = $settings['cart_discount_enabled'] ?? false;

        if ($is_cart_discount_enabled && $subtotal > 0) {
            $applicable_tier = $this->Cart_discount_model->get_applicable_tier($subtotal);
            if ($applicable_tier) {
                $cart_discount_amount = $subtotal * ($applicable_tier->discount_percentage / 100);
                $cart['cart_discount'] = $cart_discount_amount;
                $cart['applied_cart_discount_tier'] = [
                    'min_amount' => $applicable_tier->min_amount,
                    'percentage' => $applicable_tier->discount_percentage
                ];
            }
        }

        // 3. Hitung basis harga untuk diskon promo/referral
        $base_for_promo_and_referral = 0;
        if ($subtotal > 0 && $subtotal_excluding_flash_sale > 0) {
            $proportion_non_flash = $subtotal_excluding_flash_sale / $subtotal;
            $cart_discount_on_non_flash = $cart_discount_amount * $proportion_non_flash;
            $base_for_promo_and_referral = max(0, $subtotal_excluding_flash_sale - $cart_discount_on_non_flash);
        }

        // 4. Hitung Diskon Promo
        $promo_discount_amount = 0;
        if (isset($cart['applied_promo']) && $base_for_promo_and_referral > 0) {
            $applied_promo = $cart['applied_promo'];
            if ($applied_promo['discount_type'] == 'percentage') {
                $promo_discount_amount = $base_for_promo_and_referral * $applied_promo['value'];
            } else { // 'flat'
                $promo_discount_amount = min($applied_promo['value'], $base_for_promo_and_referral);
            }
        }
        $cart['promo_discount'] = $promo_discount_amount;

        // 5. Hitung Diskon Referral
        $referral_discount_amount = 0;
        if (isset($cart['applied_referral']) && $base_for_promo_and_referral > 0) {
            $applied_referral = $cart['applied_referral'];
            $referral_discount_amount = $base_for_promo_and_referral * $applied_referral['value'];
        }
        $cart['referral_discount'] = $referral_discount_amount;

        // 6. Hitung Grand Total
        $cart['grand_total'] = max(0, $subtotal - $cart_discount_amount - $promo_discount_amount - $referral_discount_amount);
    }

    /**
     * [FIXED] add_flash_sale sekarang membongkar bundle & menangani bundle kosong
     */
    public function add_flash_sale($flash_sale_id) {
        if (!$flash_sale_id) { redirect(base_url()); return; }

        if (!$this->session->userdata('is_logged_in')) {
            $this->session->set_flashdata('error', 'Anda harus login untuk membeli item flash sale.');
            redirect($this->agent->referrer() ?? 'cart');
            return;
        }

        $this->load->model('Flash_sale_model');
        $flash_sale = $this->Flash_sale_model->get_active_flash_sale_by_id($flash_sale_id);

        if (!$flash_sale || $flash_sale->stock_sold >= $flash_sale->stock_limit) {
            $this->session->set_flashdata('error', 'Maaf, penawaran flash sale sudah tidak valid atau stok habis.');
            redirect(base_url());
            return;
        }

        $cart = $this->_get_cart_from_session(); 

        // [LOGIKA ANTI-ABUSE v2]
        // Cek apakah item dari grup flash sale ini sudah ada
        $group_id_to_check = 'fs_' . $flash_sale_id;
        foreach ($cart['items'] as $item) {
            if (($item['bundle_group_id'] ?? null) == $group_id_to_check) {
                $this->session->set_flashdata('info', 'Produk flash sale ini sudah ada di keranjang Anda.');
                redirect('cart');
                return;
            }
        }
         // Juga cek item tunggal (jika BUKAN bundle)
         if ($flash_sale->product_type !== 'bundles' && isset($cart['items'][$flash_sale->product_id])) {
             $this->session->set_flashdata('info', 'Produk flash sale ini sudah ada di keranjang Anda.');
            redirect('cart');
            return;
        }


        // [LOGIKA BARU PEMBONGKARAN BUNDLE FLASH SALE]
        
        $bundle_data_fs = json_decode($flash_sale->description, true);

        // Cek apakah produk flash sale ini adalah BUNDLE DENGAN ISI
        if ($flash_sale->product_type === 'bundles' && $this->_is_valid_item_list($bundle_data_fs)) {
            
            $product_ids_in_bundle = $bundle_data_fs;
            
            // Ya, ini BUNDLE DENGAN ISI. Lakukan logika pembongkaran & rasio harga.
                
                // Hitung harga master bundle (harga flash sale)
                $master_bundle_price = $flash_sale->original_price - ($flash_sale->original_price * $flash_sale->discount_percentage / 100);
                
                $parent_bundle_name = $flash_sale->name;
                $parent_bundle_id = 'fs_' . $flash_sale_id; // ID group-nya adalah ID flash sale unik

                $original_total_price = $this->_get_bundle_original_total($product_ids_in_bundle);

                $bundle_ratio = 1.0;
                if ($original_total_price > 0 && $master_bundle_price < $original_total_price) {
                    $bundle_ratio = $master_bundle_price / $original_total_price;
                }

                $items_added_count = 0;
                foreach ($product_ids_in_bundle as $item_id_in_bundle) {
                    if (is_scalar($item_id_in_bundle)) {
                        // Panggil _add_item_to_cart, tandai sebagai flash sale
                        $result = $this->_add_item_to_cart($item_id_in_bundle, 'ranks', $cart, $parent_bundle_name, $bundle_ratio, $parent_bundle_id, true);
                        if ($result['status'] == 'success') {
                            $items_added_count++;
                        }
                    }
                }
                
                // [FIX BUG &#039;] Hapus html_escape() dari pesan sukses
                if ($items_added_count > 0) {
                     $this->session->set_flashdata('success', 'Paket Flash Sale "' . $parent_bundle_name . '" berhasil ditambahkan!');
                } else {
                     $this->session->set_flashdata('info', 'Semua item dari paket Flash Sale "' . $parent_bundle_name . '" sudah ada di keranjang.');
                }

        } else {
            // Ini BUNDLE KOSONG (command) ATAU ITEM TUNGGAL.
            // Tambahkan sebagai satu item.
            $flash_price = $flash_sale->original_price - ($flash_sale->original_price * $flash_sale->discount_percentage / 100);

            $product_name_in_cart = $flash_sale->name;
            if ($flash_sale->category === 'currency') {
                $product_name_in_cart .= ' (' . ucfirst($flash_sale->realm) . ')';
            }
            $product_name_in_cart .= ' (Flash Sale)'; // Tambahkan tag Flash Sale
    
            $cart_item = [
                'id'             => $flash_sale->product_id,
                'name'           => $product_name_in_cart,
                'price'          => $flash_price,
                'is_upgrade'     => false,
                'original_price' => $flash_sale->original_price,
                'is_flash_sale'  => true,
                'flash_sale_id'  => $flash_sale_id, // ID dari tabel flash_sales
                'bundle_group_id' => 'fs_' . $flash_sale_id // [BARU] Beri ID grup unik agar anti-abuse-nya jalan
            ];
    
            $cart['items'][$flash_sale->product_id] = $cart_item;
            $this->session->set_flashdata('success', 'Produk flash sale berhasil ditambahkan ke keranjang!');
        }
        
        // Selalu jalankan ini di akhir
        $this->_update_cart_totals($cart);
        $this->session->set_userdata('cart', $cart);
        redirect('cart');
    }

} // End of Cart class