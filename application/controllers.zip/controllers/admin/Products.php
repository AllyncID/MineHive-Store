<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends Admin_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model');
    }

    public function index() {
        $realm_filter = $this->input->get('realm', TRUE) ?: 'all';
        $data['products'] = $this->Product_model->get_all_products($realm_filter);
        $data['title'] = 'Manage Products';
        $data['current_filter'] = $realm_filter;
        
        $this->load->view('admin/templates/admin_header', $data);
        $this->load->view('admin/products/index', $data);
        $this->load->view('admin/templates/admin_footer');
    }

public function add() {
        if ($this->input->post()) {
            
            // --- [PERBAIKAN LOGIKA] ---
            // Ambil data spesifik berdasarkan tipe produk
            $product_type = $this->input->post('product_type');
            
            $data = [
                'name' => $this->input->post('name'),
                'price' => $this->input->post('price'),
                'original_price' => $this->input->post('original_price'),
                'realm' => $this->input->post('realm'),
                'product_type' => $product_type,
                'category' => $this->input->post('category'), // [TAMBAHAN] Ambil kategori
                'command' => $this->input->post('command'),
                'image_url' => $this->input->post('image_url'),
                'is_active' => $this->input->post('is_active')
            ];

            // Atur 'description' dan 'luckperms_group' berdasarkan tipe
            if ($product_type == 'rank') {
                $data['description'] = $this->input->post('description_perks');
                $data['luckperms_group'] = $this->input->post('luckperms_group');
            } elseif ($product_type == 'currency') {
                $data['description'] = $this->input->post('description_simple');
                $data['luckperms_group'] = NULL;
            } elseif ($product_type == 'bundles') {
                // Ambil array ID produk dan encode ke JSON
                $bundle_ids = $this->input->post('bundle_product_ids') ?? [];
                $data['description'] = json_encode($bundle_ids);
                $data['luckperms_group'] = NULL;
            } else {
                $data['description'] = $this->input->post('description_simple'); // Fallback
                $data['luckperms_group'] = NULL;
            }
            // --- [AKHIR PERBAIKAN LOGIKA] ---
            
            $this->Product_model->insert($data);
            
            $this->session->set_flashdata('success', 'Produk berhasil ditambahkan.');
            redirect('admin/products');
        }
        
        $data['title'] = 'Tambah Produk Baru';
        // --- [PERBAIKAN DI SINI] ---
        // Kita perlu mengambil semua produk agar bisa ditampilkan di dropdown "Isi Bundle"
        $data['all_products'] = $this->Product_model->get_all_products();
        // --- [AKHIR PERBAIKAN] ---
        
        $this->load->view('admin/templates/admin_header', $data);
        $this->load->view('admin/products/form', $data);
        $this->load->view('admin/templates/admin_footer');
    }

    public function edit($id) {
        if ($this->input->post()) {

            // --- [PERBAIKAN LOGIKA] ---
            // Ambil data spesifik berdasarkan tipe produk
            $product_type = $this->input->post('product_type');

            $data = [
                'name' => $this->input->post('name'),
                'price' => $this->input->post('price'),
                'original_price' => $this->input->post('original_price'),
                'realm' => $this->input->post('realm'),
                'product_type' => $product_type,
                'category' => $this->input->post('category'), // [TAMBAHAN] Ambil kategori
                'command' => $this->input->post('command'),
                'image_url' => $this->input->post('image_url'),
                'is_active' => $this->input->post('is_active')
            ];

            // Atur 'description' dan 'luckperms_group' berdasarkan tipe
            if ($product_type == 'rank') {
                $data['description'] = $this->input->post('description_perks');
                $data['luckperms_group'] = $this->input->post('luckperms_group');
            } elseif ($product_type == 'currency') {
                $data['description'] = $this->input->post('description_simple');
                $data['luckperms_group'] = NULL;
            } elseif ($product_type == 'bundles') {
                // Ambil array ID produk dan encode ke JSON
                $bundle_ids = $this->input->post('bundle_product_ids') ?? [];
                $data['description'] = json_encode($bundle_ids);
                $data['luckperms_group'] = NULL;
            } else {
                $data['description'] = $this->input->post('description_simple'); // Fallback
                $data['luckperms_group'] = NULL;
            }
            // --- [AKHIR PERBAIKAN LOGIKA] ---
            
            $this->Product_model->update($id, $data);
            $this->session->set_flashdata('success', 'Produk berhasil diperbarui.');
            redirect('admin/products');
        }

        $data['product'] = $this->Product_model->get_by_id($id);
        $data['title'] = 'Edit Produk';
        
        // --- [PERBAIKAN DI SINI] ---
        // Kita perlu mengambil semua produk agar bisa ditampilkan di dropdown "Isi Bundle"
        $data['all_products'] = $this->Product_model->get_all_products();
        // --- [AKHIR PERBAIKAN] ---
        
        $this->load->view('admin/templates/admin_header', $data);
        $this->load->view('admin/products/form', $data);
        $this->load->view('admin/templates/admin_footer');
    }

    public function delete($id) {
        $this->Product_model->delete($id);
        $this->session->set_flashdata('success', 'Produk berhasil dihapus.');
        redirect('admin/products');
    }

    public function duplicate($id) {
        // Panggil fungsi duplicate di model
        $new_product_id = $this->Product_model->duplicate($id);

        if ($new_product_id) {
            // Jika berhasil, beri pesan sukses
            $this->session->set_flashdata('success', 'Produk berhasil diduplikasi. Anda bisa mengedit salinannya sekarang.');
        } else {
            // Jika gagal, beri pesan error
            $this->session->set_flashdata('error', 'Gagal menduplikasi produk.');
        }

        // Arahkan kembali ke halaman daftar produk
        redirect('admin/products');
    }
}