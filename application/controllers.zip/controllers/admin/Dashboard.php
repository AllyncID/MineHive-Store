<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Admin_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->model('Product_model');
        $this->load->model('Transaction_model');
        $this->load->model('Settings_model');
        $this->load->model('Promo_popup_model'); // Load our new model
    }

    public function index() {
        $data['title'] = 'Dashboard';

        $range = $this->input->get('range', TRUE) ?: '7days';
        $days = 7;
        $filter_title = '7 Hari Terakhir';
        
        switch ($range) {
            case 'today': $days = 1; $filter_title = 'Hari Ini'; break;
            case '30days': $days = 30; $filter_title = '30 Hari Terakhir'; break;
            case 'all': $days = null; $filter_title = 'Semua Waktu'; break;
            case '7days': default: $days = 7; $filter_title = '7 Hari Terakhir'; $range = '7days'; break;
        }
        $data['filter_title'] = $filter_title;
        $data['current_range'] = $range;

        $data['total_products'] = $this->Admin_model->count_total_products();
        $data['total_transactions'] = $this->Admin_model->count_total_transactions($days);
        $data['total_revenue'] = $this->Admin_model->calculate_total_revenue($days);
        $data['recent_transactions'] = $this->Transaction_model->get_recent_transactions(5);

        $chart_days = ($days) ? $days : 30;
        $sales_data_db = $this->Admin_model->get_daily_sales_for_chart($chart_days);
        $sales_by_date = [];
        foreach ($sales_data_db as $row) { 
            $sales_by_date[$row['sale_date']] = $row['daily_total']; 
        }
        $chart_labels = [];
        $chart_data = [];
        for ($i = $chart_days - 1; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));
            $chart_labels[] = date('d M', strtotime($date));
            $chart_data[] = isset($sales_by_date[$date]) ? $sales_by_date[$date] : 0;
        }
        $data['chart_labels'] = json_encode($chart_labels);
        $data['chart_data'] = json_encode($chart_data);

        // Load settings and promo data
        $data['settings'] = $this->Settings_model->get_all_settings();
        $data['promo_popup'] = $this->Promo_popup_model->get_promo_data();

        $this->load->view('admin/templates/admin_header', $data);
        $this->load->view('admin/dashboard_view', $data);
        $this->load->view('admin/templates/admin_footer');
    }

    public function update_settings() {
        $settings_data = [
            'announcement_bar_enabled' => $this->input->post('announcement_bar_enabled'),
            'announcement_bar_text'    => $this->input->post('announcement_bar_text'),
            'announcement_bar_link'    => $this->input->post('announcement_bar_link'),
            'announcement_timer_end'   => $this->input->post('announcement_timer_end')
        ];

        $this->Settings_model->update_batch($settings_data);

        $this->session->set_flashdata('success', 'Pengaturan situs berhasil diperbarui.');
        redirect('admin/dashboard');
    }

    public function update_promo_popup() {
        if ($this->input->post()) {
            $data = [
                'title' => $this->input->post('title', TRUE),
                'promo_tier_1' => $this->input->post('promo_tier_1', TRUE),
                'promo_tier_2' => $this->input->post('promo_tier_2', TRUE),
                'promo_tier_3' => $this->input->post('promo_tier_3', TRUE),
                'promo_tier_4' => $this->input->post('promo_tier_4', TRUE),
                'promo_tier_5' => $this->input->post('promo_tier_5', TRUE),
                'is_enabled' => $this->input->post('is_enabled', TRUE)
            ];

            $this->Promo_popup_model->update_promo_data($data);
            $this->session->set_flashdata('success', 'Pengaturan Popup Promo berhasil diperbarui.');
        }
        redirect('admin/dashboard');
    }
}
