<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function index() {

        // Muat model Settings
        $this->load->model('Settings_model');
        $settings = $this->Settings_model->get_all_settings();


        // === AMBIL SEMUA DATA FLASH SALE YANG AKTIF ===
        $this->load->model('Flash_sale_model');
        // Ubah di sini: Hapus angka 3 untuk mengambil semua flash sale aktif
        $data['flash_sales'] = $this->Flash_sale_model->get_active_flash_sales();
        // ===============================================

        // Siapkan data untuk dikirim ke view header
        $data['announcement_bar'] = [
            'enabled'   => $settings['announcement_bar_enabled'] ?? false,
            'text'      => $settings['announcement_bar_text'] ?? '',
            'link'      => $settings['announcement_bar_link'] ?? '',
            'timer_end' => $settings['announcement_timer_end'] ?? ''
        ];

        $data['title'] = 'Welcome | Mine Hive';

        // Memuat driver cache
        $this->load->driver('cache', array('adapter' => 'file'));

        // --- Mengambil Jumlah Player Minecraft Online ---
        if ( ! $online_players = $this->cache->get('minecraft_online_players')) {
            $mc_api_url = 'https://api.mcsrvstat.us/2/minehive.id';
            $mc_data_json = @file_get_contents($mc_api_url);
            $mc_data = json_decode($mc_data_json);

            if ($mc_data && isset($mc_data->online) && $mc_data->online) {
                $online_players = $mc_data->players->online;
            } else {
                $online_players = "Offline";
            }
            $this->cache->save('minecraft_online_players', $online_players, 300);
        }
        $data['online_players'] = $online_players;

        // --- Mengambil Jumlah Anggota Discord Online ---
        if ( ! $discord_online = $this->cache->get('discord_online_members')) {
            $discord_api_url = 'https://discord.com/api/v9/invites/minehive?with_counts=true';
            $discord_data_json = @file_get_contents($discord_api_url);
            $discord_data = json_decode($discord_data_json);

            if ($discord_data && isset($discord_data->approximate_presence_count)) {
                $discord_online = $discord_data->approximate_presence_count;
            } else {
                $discord_online = "N/A";
            }
            $this->cache->save('discord_online_members', $discord_online, 300);
        }
        $data['discord_online'] = $discord_online;

        // --- Mengambil Data Supporters ---
        $this->load->model('Store_model');
        $this->load->model('Transaction_model');

            $data['top_donator'] = $this->Store_model->get_top_donators(1);
            $data['recent_supporters'] = $this->Transaction_model->get_recent_transactions(10);

        // Memuat view dengan semua data yang sudah kita kumpulkan
        $this->load->view('templates/header', $data);
        $this->load->view('home_view', $data);
        $this->load->view('templates/footer');
    }

    /**
     * [FITUR BARU] Endpoint untuk Social Proof
     * Mengembalikan 5 transaksi terakhir yang sudah selesai.
     */
    public function get_recent_purchases() {
        header('Content-Type: application/json');
        
        $this->load->model('Transaction_model');
        
        // Ambil 5 transaksi terakhir (fungsi ini sudah memfilter status 'completed')
        $transactions = $this->Transaction_model->get_recent_transactions(5);
        
        // Format data agar ringan untuk JSON
        $purchases = [];
        foreach ($transactions as $trx) {
            // Kita hanya ambil item pertama jika pembeliannya banyak
            $first_item = explode(',', $trx->purchased_items)[0];
            
            $purchases[] = [
                'username' => $trx->player_username,
                'realm'    => ucfirst($trx->realm), // Misal: "Survival"
                'items'    => $first_item // Misal: "[VIP] Rank"
            ];
        }
        
        echo json_encode($purchases);
    }
}
