<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Store_model');
        $this->load->model('Transaction_model');
        $this->load->model('Promo_model');
        $this->load->model('Affiliate_model'); // (Saya tambahkan ini di construct)
        $this->config->load('xendit', TRUE); // Muat konfigurasi Xendit kita

        
        // Wajib login untuk mengakses controller ini
        if (!$this->session->userdata('is_logged_in')) {
            $this->session->set_flashdata('error', 'Anda harus login untuk melanjutkan.');
            redirect(base_url());
        }
    }

    /**
     * Fungsi private untuk mengirim command via Pterodactyl Client API.
     */
    private function _send_pterodactyl_command($command, $server_id) {
        $panel_url = $this->config->item('pterodactyl_panel_url');
        $api_key = $this->config->item('pterodactyl_api_key');

        if (empty($panel_url) || empty($api_key) || empty($server_id)) {
            log_message('error', 'Pterodactyl Gagal: Konfigurasi (URL/Key/ServerID) tidak lengkap.');
            return false;
        }

        $api_url = rtrim($panel_url, '/') . '/api/client/servers/' . $server_id . '/command';
        $post_data = json_encode(['command' => $command]);
        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $api_key,
            'Content-Type: application/json',
            'Accept: Application/vnd.pterodactyl.v1+json'
        ]);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        // --- [LOG TAMBAHAN DI SINI] ---
        // Kita log *setiap* panggilan Pterodactyl untuk melihat HTTP code-nya
        log_message('error', '--- [LOG DEBUG PTERODACTYL] --- Server: ' . $server_id . ' | Command: ' . $command . ' | HTTP Code: ' . $http_code);
        // --- [AKHIR LOG TAMBAHAN] ---


        if ($http_code !== 204) {
            log_message('error', '================ PTERODACTYL API CALL FAILED (CODE BUKAN 204) ================');
            log_message('error', 'Server ID Target: ' . $server_id);
            log_message('error', 'Perintah: ' . $command);
            log_message('error', 'HTTP Status Code Diterima: ' . $http_code);
            log_message('error', 'Pesan Error cURL (jika ada): ' . $curl_error);
            log_message('error', 'Respons Penuh dari API: ' . $response);
            log_message('error', '===========================================================');
            return false;
        }
        return true;
    }

    public function checkout()
    {
        // Bagian 1: Validasi Awal & Logika Gifting
        if (!$this->session->userdata('is_logged_in')) {
            redirect(base_url());
            return;
        }

        $cart = $this->session->userdata('cart');
        if (empty($cart) || empty($cart['items'])) {
            redirect('cart');
            return;
        }

        $is_gifting = $this->input->post('is_gift') == '1';
        $contains_upgrade = false;
        foreach ($cart['items'] as $item) {
            if (!empty($item['is_upgrade'])) {
                $contains_upgrade = true;
                break;
            }
        }
        if ($contains_upgrade && $is_gifting) {
            $this->session->set_flashdata('error', 'Rank Upgrades tidak bisa dikirim sebagai hadiah.');
            redirect('cart');
            return;
        }

        $penerima_username = $this->session->userdata('username');
        if ($is_gifting) {
            $gifting_username = trim($this->input->post('gifting_username'));
            if (!empty($gifting_username)) {
                $penerima_username = $gifting_username;
            } else {
                $this->session->set_flashdata('error', 'Username penerima hadiah tidak boleh kosong.');
                redirect('cart');
                return;
            }
        }

        // Bagian 2: PERBAIKAN - Catat Transaksi & Rincian Item ke DB
        
        // [PERBAIKAN] Dapatkan ID Afiliasi dari $cart['applied_referral']
        $affiliate_id = null;
        $commission_rate = null;
        if (isset($cart['applied_referral'])) { // <--- PERUBAHAN DI SINI
            $affiliate_id = $cart['applied_referral']['affiliate_id']; // <--- PERUBAHAN DI SINI
            
            // --- INI DIA PERBAIKANNYA ---
            // 1. Ambil data lengkap afiliasi berdasarkan ID
            $affiliate_data = $this->Affiliate_model->get_affiliate_by_id($affiliate_id);

            // 2. Cek jika data ada, lalu ambil 'commission_rate' (ini adalah desimal, cth: 0.03)
            if ($affiliate_data) {
                // Ambil rate komisi berdasarkan badge afiliasi
                $badge_info = $this->Affiliate_model->get_badge_info($affiliate_data->total_sales, $affiliate_data->total_transactions);
                $commission_rate = $badge_info['commission_rate'];
            }
            // -----------------------------
        }
        
        // Siapkan data transaksi utama
        $transaction_data = [
            'player_uuid' => $this->session->userdata('uuid'),
            'player_username' => $this->session->userdata('username'),
            'subtotal' => $cart['subtotal'],
            // [PERBAIKAN] Jumlahkan kedua diskon untuk kolom 'discount'
            'discount' => ($cart['promo_discount'] ?? 0) + ($cart['referral_discount'] ?? 0), // <--- PERUBAHAN DI SINI
            'cart_discount' => $cart['cart_discount'], // Simpan diskon keranjang
            'grand_total' => $cart['grand_total'],
            'status' => 'pending',
            'payment_method' => 'xendit',
            'cart_data' => json_encode($cart),
            'is_gift' => $is_gifting ? 1 : 0,
            'gift_recipient_username' => $is_gifting ? $penerima_username : null,
            // [PERBAIKAN] Ambil kode promo dari $cart['applied_promo']
            'promo_code_used' => $cart['applied_promo']['code'] ?? null, // <--- PERUBAHAN DI SINI
            'affiliate_id' => $affiliate_id, // Simpan ID afiliasi
            'affiliate_commission_rate' => $commission_rate // Simpan rate komisi saat itu
            // 'affiliate_commission_amount' akan di-isi oleh webhook
        ];

        // Mulai transaksi database untuk menjamin semua data tersimpan atau tidak sama sekali
        $this->db->trans_start();

        // 1. Catat transaksi utama dan dapatkan ID-nya
        $transaction_id = $this->Transaction_model->log_transaction($transaction_data);

        // 2. Loop dan catat setiap item yang dibeli ke tabel `transaction_items`
        if ($transaction_id) {
            foreach ($cart['items'] as $item) {
                $this->Transaction_model->log_transaction_item([
                    'transaction_id' => $transaction_id,
                    'product_id'     => $item['id'],
                    'product_name'   => $item['name'],
                    'price'          => $item['price']
                ]);
            }
        }

        // Selesaikan transaksi database
        $this->db->trans_complete();

        // Jika terjadi error saat menyimpan ke database, batalkan proses
        if ($this->db->trans_status() === FALSE) {
            log_message('error', 'Gagal menyimpan transaksi atau item transaksi ke database.');
            $this->session->set_flashdata('error', 'Terjadi kesalahan pada database. Silakan coba lagi.');
            redirect('cart');
            return;
        }

        // Bagian 3: Buat Invoice Xendit (Tidak Berubah)
        
        $api_key = $this->config->item('xendit_api_key', 'xendit');
        
        $params = [
            'external_id' => 'MH-INV-' . $transaction_id,
            'amount' => (int) $cart['grand_total'],
            'payer_email' => $this->session->userdata('email') ?? 'guest@minehive.id',
            'description' => 'Pembelian item di MineHive Store #' . $transaction_id,
            'success_redirect_url' => base_url('payment/success'),
            'failure_redirect_url' => base_url('payment/failed'),
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.xendit.co/v2/invoices");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Basic " . base64_encode($api_key . ":"),
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $result = json_decode($response, true);
        
        if ($http_code == 200 && isset($result['invoice_url'])) {
            redirect($result['invoice_url']);
        } else {
            log_message('error', 'Xendit cURL Gagal: ' . $response);
            $this->session->set_flashdata('error', 'Gagal terhubung ke gerbang pembayaran. Silakan coba beberapa saat lagi.');
            redirect('cart');
        }
    }

    /**
     * Menerima notifikasi dari Xendit dan menjalankan semua proses otomatis.
     */
    public function xendit_webhook()
    {
        // 1. Verifikasi Keamanan (SANGAT PENTING) - Tidak berubah
        $xendit_webhook_token = $this->config->item('xendit_webhook_token', 'xendit');
        $request_headers = getallheaders();
        $x_callback_token = $request_headers['x-callback-token'] ?? '';

        if ($x_callback_token !== $xendit_webhook_token) {
            http_response_code(403); // Forbidden
            log_message('error', 'Xendit Webhook: Invalid callback token.');
            return;
        }

        // 2. Ambil data JSON dari Xendit - Tidak berubah
        $request_body = file_get_contents('php://input');
        // Ganti nama variabel ke $payload agar lebih jelas
        $payload = json_decode($request_body, true);
        
        // Log mentah untuk debugging jika diperlukan
        log_message('debug', 'Xendit Webhook Payload Received: ' . $request_body);

        // ======================================================================
        // MODIFIKASI UTAMA: MENANGANI STRUKTUR DATA WEBHOOK INVOICE
        // ======================================================================

        // (LOG 1: Webhook diterima)
        log_message('error', '--- [LOG DEBUG AFILIASI] --- Webhook Xendit Diterima. Event: ' . ($payload['event'] ?? 'UNKNOWN'));

        // 3. Hanya proses jika event-nya adalah 'invoice.paid'
        if (isset($payload['event']) && $payload['event'] == 'invoice.paid') {
            
            log_message('info', "Xendit Webhook: Event 'invoice.paid' terdeteksi.");

            // Ambil data invoice dari dalam objek 'data'
            $invoice_data = $payload['data'];

            // Pastikan status di dalam data invoice adalah PAID
            if (isset($invoice_data['status']) && $invoice_data['status'] == 'PAID') {
                
                // Ekstrak ID transaksi kita dari external_id di dalam data invoice
                $external_id_parts = explode('-', $invoice_data['external_id']);
                $transaction_id = $external_id_parts[2] ?? null;

                // (LOG 2: Transaksi ID ditemukan)
                log_message('error', '--- [LOG DEBUG AFILIASI] --- Invoice PAID. Mencari Transaksi ID: ' . $transaction_id);

                if ($transaction_id) {
                    $transaction = $this->Transaction_model->get_transaction_by_id($transaction_id);

                    // Hanya proses jika transaksi ada dan statusnya masih 'pending'
                    if ($transaction && $transaction['status'] == 'pending') {
                        
                        log_message('info', 'Xendit Webhook: Memproses transaksi ID ' . $transaction_id . ' dengan status pending.');
                        
                        // Ambil data keranjang DAN pembeli dari transaksi
                        $cart = json_decode($transaction['cart_data'], true);
                        $penerima_username = $transaction['gift_recipient_username'] ?? $transaction['player_username'];
                        $pembeli_username = $transaction['player_username'];
                        $pembeli_uuid = $transaction['player_uuid']; // [MODIFIKASI] Ambil UUID pembeli
                        $grand_total = $transaction['grand_total']; // Ambil grand total dari DB
                        $affiliate_id = $transaction['affiliate_id']; // Ambil ID afiliasi dari DB
                        // $commission_rate = $transaction['affiliate_commission_rate']; // Kita tidak perlu ini lagi

                        
                        // (LOG 3: Data Afiliasi ditemukan)
                        log_message('error', '--- [LOG DEBUG AFILIASI] --- Transaksi ' . $transaction_id . ' ditemukan. Affiliate ID: ' . ($affiliate_id ?? 'TIDAK ADA'));
                        
                        $this->db->trans_start();

                        // ==========================================================
                        // === PEROMBAKAN LOGIKA (SESUAI PERMINTAAN ANDA) ===
                        // ==========================================================
                        
                        // A. Kirim Perintah ke Pterodactyl (Dijalankan Dulu)
                        $all_commands_success = true;
                        
                        // (LOG 4: Memulai Loop Pterodactyl)
                        log_message('error', '--- [LOG DEBUG AFILIASI] --- Memulai loop Pterodactyl...');

                        foreach ($cart['items'] as $item) {
                            $product = $this->Store_model->get_product_by_id($item['id']);
                            if ($product) {
                                $realm = trim($product['realm']);
                                $config_key_name = 'pterodactyl_server_id_' . strtolower($realm);
                                $server_id = $this->config->item($config_key_name);
                                if (!empty($server_id)) {
                                    $command = str_replace('{username}', $penerima_username, $product['command']);
                                    
                                    // (LOG 5: Mengirim command)
                                    log_message('error', '--- [LOG DEBUG AFILIASI] --- Mengirim command Ptero: ' . $command);

                                    if (!$this->_send_pterodactyl_command($command, $server_id)) {
                                        $all_commands_success = false; 
                                        // (LOG 6: GAGAL)
                                        log_message('error', '--- [LOG DEBUG AFILIASI] --- Pterodactyl GAGAL di item: ' . $item['name'] . '. Loop dihentikan.');
                                        break;
                                    } else {
                                        // (LOG 6: SUKSES)
                                        log_message('error', '--- [LOG DEBUG AFILIASI] --- Pterodactyl SUKSES untuk item: ' . $item['name']);
                                    }
                                }
                            }
                        }

                        // (LOG 7: Status Final Pterodactyl)
                        log_message('error', '--- [LOG DEBUG AFILIASI] --- Loop Pterodactyl selesai. Final status $all_commands_success: ' . ($all_commands_success ? 'TRUE' : 'FALSE'));


                        // B. Proses sisa (Log Aktivitas, Increment Usage, Discord)
                        // HANYA JIKA PTERODACTYL SUKSES
                        if($all_commands_success) {
                            
                            // (LOG 8: Masuk Blok Sukses)
                            log_message('error', '--- [LOG DEBUG AFILIASI] --- (Blok SUKSES) Pterodactyl berhasil. Melanjutkan proses afiliasi.');

                            // [MODIFIKASI] Cek Bonus Pembelian Pertama
                            $transaction_count = $this->Transaction_model->get_completed_transaction_count($pembeli_uuid);
                            
                            // (PERMINTAAN 1) Cek apakah ini pembeli pertama
                            $is_first_time_buyer = ($transaction_count == 0);

                            if ($is_first_time_buyer) {
                                // Ini adalah pembelian pertama!
                                log_message('info', 'First-Time Buyer Detected for UUID: ' . $pembeli_uuid);
                                $this->load->model('First_bonus_model');
                                $bonus_commands = $this->First_bonus_model->get_active_commands();
                                
                                foreach ($bonus_commands as $bonus) {
                                    // Asumsi bonus command HANYA berlaku untuk realm 'survival'
                                    // TODO: Anda mungkin perlu membuat ini lebih fleksibel nanti
                                    $server_id_bonus = $this->config->item('pterodactyl_server_id_survival');
                                    if (!empty($server_id_bonus)) {
                                        $command_to_send = str_replace('{username}', $penerima_username, $bonus->reward_command);
                                        log_message('info', 'Sending First-Time Bonus Command: ' . $command_to_send);
                                        $this->_send_pterodactyl_command($command_to_send, $server_id_bonus);
                                        // Kita tidak menghentikan proses jika bonus gagal
                                    }
                                }
                            }
                            // [AKHIR MODIFIKASI BONUS FIRST TIME]


                            // [FITUR BARU] PROSES HADIAH GOSOK BERHADIAH
                            log_message('error', '[Scratch Event] Memulai proses cek hadiah gosok...');
                            $this->load->model('Scratch_event_model');
                            $this->load->model('Settings_model'); // (Sudah di-load di construct, tapi pastikan saja)

                            $scratch_settings = $this->Settings_model->get_all_settings();
                            if (!empty($scratch_settings['scratch_event_enabled']) && $scratch_settings['scratch_event_enabled'] == '1') {
                                
                                log_message('error', '[Scratch Event] Fitur AKIF. Cek tier untuk Grand Total: ' . $grand_total);
                                $tier = $this->Scratch_event_model->get_applicable_tier($grand_total);

                                if ($tier) {
                                    log_message('error', '[Scratch Event] Customer masuk Tier: ' . $tier->title);
                                    $reward = $this->Scratch_event_model->get_random_reward_for_tier($tier->id);

                                    if ($reward) {
                                        log_message('error', '[Scratch Event] Customer memenangkan: ' . $reward->display_name);

                                        // 1. Eksekusi jika command
                                        if ($reward->reward_type == 'command') {
                                            $this->load->model('Store_model'); // (Sudah di-load di construct, tapi pastikan saja)
                                            
                                            // Ambil item pertama dari keranjang
                                            $first_item_id = array_key_first($cart['items']);
                                            $first_item = $cart['items'][$first_item_id];
                                            $product = $this->Store_model->get_product_by_id($first_item['id']);

                                            if ($product) {
                                                $realm = trim($product['realm']);
                                                $config_key_name = 'pterodactyl_server_id_' . strtolower($realm);
                                                $server_id = $this->config->item($config_key_name);
                                                
                                                if ($server_id) {
                                                    $command = str_replace('{username}', $penerima_username, $reward->reward_value);
                                                    $this->_send_pterodactyl_command($command, $server_id);
                                                    log_message('error', '[Scratch Event] EKSEKUSI COMMAND: ' . $command . ' di server ' . $realm);
                                                } else {
                                                    log_message('error', '[Scratch Event] GAGAL EKSEKUSI: Server ID Pterodactyl untuk realm ' . $realm . ' tidak ditemukan.');
                                                }
                                            }
                                        }

                                        // 2. Catat kemenangan (untuk SEMUA tipe hadiah)
                                        $this->Scratch_event_model->log_won_reward([
                                            'transaction_id' => $transaction_id,
                                            'player_uuid'    => $pembeli_uuid, // Gunakan UUID pembeli
                                            'reward_bank_id' => $reward->id
                                        ]);
                                        log_message('error', '[Scratch Event] Kemenangan dicatat di db untuk UUID: ' . $pembeli_uuid);

                                    } else {
                                        log_message('error', '[Scratch Event] Tier ditemukan, tapi GAGAL mengambil hadiah (Pool Hadiah mungkin kosong).');
                                    }
                                } else {
                                    log_message('error', '[Scratch Event] Belanja customer tidak memenuhi syarat tier manapun.');
                                }
                            } else {
                                log_message('error', '[Scratch Event] Fitur NON-AKTIF. Proses dilewati.');
                            }
                            // [AKHIR FITUR BARU] GOSOK BERHADIAH


                            // 1. Panggil fungsi log_affiliate_sale. 
                            // Ini adalah "JANTUNG" logika afiliasi.
                            $commission_data = null;
                            if ($affiliate_id) {
                                // (LOG 9: Memanggil log_affiliate_sale)
                                log_message('error', '--- [LOG DEBUG AFILIASI] --- (Blok SUKSES) Memanggil Affiliate_model->log_affiliate_sale() untuk ID: ' . $affiliate_id . ' | Amount: ' . $grand_total);
                                
                                $commission_data = $this->Affiliate_model->log_affiliate_sale($affiliate_id, $grand_total);
                                
                                // (LOG 10: Hasil dari log_affiliate_sale)
                                log_message('error', '--- [LOG DEBUG AFILIASI] --- (Blok SUKSES) Hasil log_affiliate_sale: ' . json_encode($commission_data));
                            }

                            // 2. Update status transaksi menjadi 'completed'
                            // dan simpan jumlah komisi yang DIKEMBALIKAN oleh model.
                            $commission_amount_to_log = ($commission_data && isset($commission_data['commission_amount'])) ? $commission_data['commission_amount'] : 0;
                            
                            $this->Transaction_model->update_transaction_status(
                                $transaction_id, 
                                'completed', 
                                $commission_amount_to_log // Simpan jumlah komisi
                            );


                            // --- (LOGIKA AFILIASI DISESUAIKAN) ---
                            if ($affiliate_id && $commission_data) {
                                
                                // (LOG 11: Masuk ke blok log aktivitas)
                                log_message('error', '--- [LOG DEBUG AFILIASI] --- (Blok SUKSES) Masuk blok log_activity.');

                                // 3. Catat aktivitas (untuk riwayat)
                                // (Kita ambil data dari $commission_data yang dikembalikan)
                                $this->Affiliate_model->log_activity([
                                    'affiliate_id' => $affiliate_id,
                                    'type'         => 'commission',
                                    'amount'       => $commission_data['commission_amount'],
                                    'description'  => 'Komisi ' . ($commission_data['commission_rate'] * 100) . '% dari ' . $pembeli_username . ' (Trx: #' . $transaction_id . ')'
                                ]);
                                
                                // 4. Update pemakaian KODE
                                // [PERBAIKAN] Ambil kode referral dari $cart['applied_referral']
                                $this->Affiliate_model->increment_code_usage($cart['applied_referral']['code']); // <--- PERUBAHAN DI SINI
                            
                            } else if (isset($cart['applied_promo'])) { // <--- PERUBAHAN DI SINI
                                // Logika promo non-afiliasi
                                // [PERBAIKAN] Ambil kode promo dari $cart['applied_promo']
                                $this->Promo_model->increment_usage($cart['applied_promo']['code']); // <--- PERUBAHAN DI SINI
                            }
                            
                            // 5. Kirim notif ke Discord (Terakhir)
                            // (PERMINTAAN 1) Kirim status $is_first_time_buyer ke Discord
                            $this->_send_to_discord_webhook(
                                $cart, 
                                $pembeli_username, 
                                ($transaction['is_gift'] ? $penerima_username : null),
                                $is_first_time_buyer // <--- VARIABEL BARU
                            );
                        
                        } else {
                            // JIKA PTERODACTYL GAGAL
                            // (LOG 12: Blok Gagal)
                            log_message('error', '--- [LOG DEBUG AFILIASI] --- (Blok GAGAL) $all_commands_success bernilai FALSE. Proses afiliasi dan Discord DIBATALKAN.');
                            // Kita tidak meng-update status jadi 'completed'
                            // Biarkan 'pending' agar bisa di-cek manual.
                        }
                        
                        // ==========================================================
                        // === AKHIR PEROMBAKAN LOGIKA                           ===
                        // ==========================================================

                        $this->db->trans_complete();

                    } else {
                        // Transaksi sudah diproses atau tidak ditemukan, ini bukan error, hanya diabaikan.
                        log_message('info', 'Xendit Webhook: Transaksi ID ' . $transaction_id . ' diterima, tapi diabaikan karena status bukan pending atau tidak ditemukan.');
                    }
                } else {
                    log_message('error', 'Xendit Webhook: Gagal mengekstrak Transaction ID dari external_id: ' . $invoice_data['external_id']);
                }
            } else {
                // Event 'invoice.paid' tapi status internalnya bukan PAID
                 log_message('info', 'Xendit Webhook: Event invoice.paid diterima, tapi status internal bukan PAID. Status: ' . ($invoice_data['status'] ?? 'NULL'));
            }
        } else {
            // Webhook diterima tapi bukan event yang kita proses
            log_message('info', 'Xendit Webhook: Event diterima tapi diabaikan. Event: ' . ($payload['event'] ?? 'NULL'));
        }
        
        // Kirim respons OK 200 ke Xendit untuk menandakan notifikasi sudah diterima dengan baik
        http_response_code(200);
    }

    /**
     * Helper function to format a price line for the Discord embed.
     * This pads strings to create aligned columns.
     * @param string $label Label (e.g., "Subtotal cih :")
     * @param string $price The price string (e.g., "Rp 100.000" or "- Rp 10.000")
     * @param string $suffix Optional suffix (e.g., "(BUDI01)")
     * @param int $labelWidth Width to pad the label to (e.g., 20)
     * @param int $priceWidth Width to pad the price to (e.g., 15)
     * @return string Formatted line.
     */
    private function _format_discord_line($label, $price, $suffix = '', $labelWidth = 20, $priceWidth = 15) {
        // Pad label to the right
        $paddedLabel = str_pad($label, $labelWidth, ' ', STR_PAD_RIGHT);
        
        // Pad price to the left
        $paddedPrice = str_pad($price, $priceWidth, ' ', STR_PAD_LEFT);
        
        // Add suffix if it exists
        $line = $paddedLabel . $paddedPrice;
        if (!empty($suffix)) {
            $line .= ' ' . $suffix;
        }
        
        return $line;
    }


    // (PERMINTAAN 1) Tambahkan parameter $is_first_time_buyer
    private function _send_to_discord_webhook($cart, $pembeli_username, $penerima_username = null, $is_first_time_buyer = false) {
        $webhook_url = $this->config->item('discord_webhook_url');
        if (empty($webhook_url)) {
            return;
        }

        // --- Membangun Pesan Embed yang Dinamis ---
        $item_list_raw = [];
        $is_upgrade_purchase = false;
        foreach ($cart['items'] as $item) {
            $item_list_raw[] = str_replace(' (Upgrade)', '', $item['name']);
            if (!empty($item['is_upgrade'])) {
                $is_upgrade_purchase = true;
            }
        }
        $item_string = implode("\n", $item_list_raw);

        // --- [PERUBAHAN FORMAT HARGA DITERAPKAN] ---
        $labelWidth = 20; // Lebar untuk label
        $priceWidth = 15; // Lebar untuk harga
        
        $subtotal_text = $this->_format_discord_line(
            'Subtotal :', 
            'Rp ' . number_format($cart['subtotal'], 0, ',', '.'),
            '', $labelWidth, $priceWidth
        );
        
        $cart_discount_text = $this->_format_discord_line(
            'Diskon Belanja :', 
            '- Rp ' . number_format($cart['cart_discount'], 0, ',', '.'),
            '', $labelWidth, $priceWidth
        );
        
        $promo_discount_text = $this->_format_discord_line(
            'Diskon Promo:', 
            '- Rp ' . number_format($cart['promo_discount'], 0, ',', '.'),
            isset($cart['applied_promo']['code']) ? "(" . $cart['applied_promo']['code'] . ")" : '',
            $labelWidth, $priceWidth
        );
        
        $referral_discount_text = $this->_format_discord_line(
            'Diskon Referral:', 
            '- Rp ' . number_format($cart['referral_discount'], 0, ',', '.'),
            isset($cart['applied_referral']['code']) ? "(" . $cart['applied_referral']['code'] . ")" : '',
            $labelWidth, $priceWidth
        );
        
        $total_text = $this->_format_discord_line(
            'Grand Total   d:', 
            'Rp ' . number_format($cart['grand_total'], 0, ',', '.'),
            '', $labelWidth, $priceWidth
        );
        
        $separator = str_repeat("─", $labelWidth + $priceWidth);
        // --- [AKHIR PERUBAHAN HARGA] ---


        $details_value = "```\n" . $item_string . "\n\n";
        $details_value .= $subtotal_text . "\n";
        if ($cart['cart_discount'] > 0) {
             $details_value .= $cart_discount_text . "\n";
        }
        
        if ($cart['promo_discount'] > 0) {
            $details_value .= $promo_discount_text . "\n";
        }
        
        if ($cart['referral_discount'] > 0) {
            $details_value .= $referral_discount_text . "\n";
        }

        $details_value .= $separator . "\n"; // Gunakan separator baru
        $details_value .= $total_text . "\n```";

        $author_name = html_escape($pembeli_username);
        if ($is_first_time_buyer) {
            $author_name = '⭐ ' . $author_name; // Tambahkan emoji
        }

        $author_icon_url = 'https://minotar.net/avatar/' . html_escape($pembeli_username) . '/128';
        $embed_title = 'Pembelian Baru';
        $embed_description = 'Telah menyelesaikan pembelian dengan total **Rp ' . number_format($cart['grand_total'], 0, ',', '.') . '**';

        if ($penerima_username && $penerima_username !== $pembeli_username) {
            $embed_title = 'Hadiah Baru';
            $embed_description = 'Telah memberikan **' . html_escape(implode(', ', $item_list_raw)) . '** kepada **' . html_escape($penerima_username) . '**';
        } elseif ($is_upgrade_purchase) {
            $embed_title = 'Rank Upgraded!';
            $embed_description = 'Telah upgrade rank menjadi **' . html_escape($item_list_raw[0]) . '**';
        }

        $embed_fields = [];
        $embed_fields[] = [
            'name' => 'Rincian Pembelian',
            'value' => $details_value,
            'inline' => false
        ];

        $embed_data = [
            'content' => '',
            'embeds' => [[
                'author' => [
                    'name' => $author_name,
                    'icon_url' => $author_icon_url
                ],
                'description' => $embed_description,
                'color' => "4886754",
                'fields' => $embed_fields,
                'footer' => [
                    'text' => 'MineHive Store'
                ],
                'timestamp' => date('c')
            ]]
        ];

        $json_data = json_encode($embed_data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $ch = curl_init($webhook_url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        curl_close($ch);
    }

    /**
     * Menampilkan halaman notifikasi sukses.
     */
    public function success() {
        // 1. Siapkan pesan untuk ditampilkan di dalam popup
        $this->session->set_flashdata('success', 'Pembayaran Anda telah berhasil diterima dan sedang kami proses!');

        // 2. Hapus keranjang belanja agar tidak bisa di-checkout dua kali
        $this->session->unset_userdata('cart');

        // 3. Langsung arahkan (redirect) ke halaman utama
        redirect(base_url());
    }

    /**
     * Menampilkan halaman notifikasi gagal.
     */
    public function failed() {
        // 1. Siapkan pesan error untuk ditampilkan di dalam popup
        $this->session->set_flashdata('error', 'Pembayaran gagal atau telah Anda batalkan. Keranjang Anda tetap tersimpan.');

        // 2. PENTING: JANGAN hapus keranjang, agar pengguna bisa mencoba lagi.

        // 3. Langsung arahkan (redirect) ke halaman utama
        redirect(base_url());
    }

}