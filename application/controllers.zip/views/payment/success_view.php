<div class="payment-status-wrapper">
    <div class="payment-status-container success">
        <div class="status-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <h1>Pembayaran Berhasil!</h1>
        <p>
            <?php 
                if ($this->session->flashdata('success')) {
                    echo html_escape($this->session->flashdata('success'));
                } else {
                    echo 'Terima kasih, item Anda sedang dalam proses pengiriman ke dalam game.';
                }
            ?>
        </p>
        <a href="<?= base_url(); ?>" class="btn btn-primary">Kembali ke Home</a>
    </div>
</div>