<div class="payment-status-wrapper">
    <div class="payment-status-container failed">
        <div class="status-icon">
            <i class="fas fa-times-circle"></i>
        </div>
        <h1>Pembayaran Gagal</h1>
        <p>
            <?php 
                if ($this->session->flashdata('error')) {
                    echo html_escape($this->session->flashdata('error'));
                } else {
                    echo 'Terjadi kesalahan saat memproses pembayaran Anda. Silakan coba lagi atau hubungi admin.';
                }
            ?>
        </p>
        <a href="<?= base_url('cart'); ?>" class="btn btn-secondary">Kembali ke Keranjang</a>
    </div>
</div>