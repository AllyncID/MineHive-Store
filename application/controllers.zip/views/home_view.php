<div class="container">

<?php if (isset($flash_sales) && !empty($flash_sales)): ?>
    <div class="flash-sale-section">
        <h3 class="flash-sale-main-title">FLASH SALE</h3>
        <div class="fs-grid-v2">
            
            <?php foreach($flash_sales as $fs): ?>
                <?php
                    $flash_price = $fs->original_price - ($fs->original_price * $fs->discount_percentage / 100);
                ?>
                <a href="<?= base_url('cart/add_flash_sale/' . $fs->id); ?>" class="fs-card-v2-link" data-aos="fade-up">
                    <div class="fs-card-v2">
                        <div class="fs-card-image-v2">
                            <img src="<?= html_escape($fs->image_url); ?>" alt="<?= html_escape($fs->name); ?>">
                            <span class="fs-discount-badge"><?= $fs->discount_percentage; ?>%</span>
                        </div>
                        <div class="fs-card-body-v2">
                                <h4 class="fs-title-v2">
                                    <?php 
                                        // Logika Baru: Hanya tambahkan nama realm jika kategorinya 'currency'
                                        if ($fs->category === 'currency') {
                                            echo html_escape($fs->name) . ' (' . ucfirst(html_escape($fs->realm)) . ')';
                                        } else {
                                            echo html_escape($fs->name);
                                        }
                                    ?>
                                </h4>
                            <p class="fs-price-v2">Rp <?= number_format($flash_price, 0, ',', '.'); ?></p>
                            <div class="fs-timer" data-end-time="<?= $fs->end_date; ?>">
                                <i class='bx bx-time-five'></i>
                                <strong class="flash-sale-countdown">00:00:00</strong>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; ?>

        </div>
    </div>
<?php endif; ?>
    <div class="main-cards-container">
        <a href="#" class="main-card card-ranks action-btn" data-type="rank">
            <div class="main-card-content">
                <h2>RANKS</h2>
                <p>Click to view &rarr;</p>
            </div>
            <img src="https://i.imgur.com/57NNhTW.png" class="main-card-bg-image-ranks" alt="">
        </a>
        <a href="#" class="main-card card-upgrades action-btn" data-type="rank_upgrades">
            <div class="main-card-content">
                <h2>UPGRADES</h2>
                <p>Click to view &rarr;</p>
            </div>
            <img src="https://i.imgur.com/8EyRbey.png" class="main-card-bg-image-ranks" alt="">
        </a>
        
        <a href="#" class="main-card card-bucks action-btn" data-type="currency">
            <div class="main-card-content">
                <h2>BUCKS</h2>
                <p>Click to view &rarr;</p>
            </div>
            <img src="<?= base_url('assets/images/bucks.png'); ?>" class="main-card-bg-image-bucks" alt="">
        </a>
        <a href="#" class="main-card card-bundles action-btn" data-type='bundles'> <div class="main-card-content">
                <h2>BUNDLES</h2>
                <p>Click to view &rarr;</p>
            </div>
            <img src="https://i.imgur.com/zbF2VxQ.png" class="main-card-bg-image-ranks" alt="">
        </a>
    </div>

    <div class="supporters-section-v2">
        
        <div class="top-supporter-card">
            <h3 class="supporter-v2-title">TOP SUPPORTER</h3>
            <?php if (!empty($top_donator)): 
                $donator = $top_donator[0]; // Ambil data donatur pertama
                // Logika untuk avatar Bedrock
                $username = $donator['player_username'];
                $avatar_url = 'https://minotar.net/avatar/' . rawurlencode($username) . '/80';
                if (strpos($username, '.') === 0) {
                    $avatar_url = 'https://minotar.net/avatar/Steve/80';
                }
            ?>
                <div class="top-supporter-info">
                    <img src="<?= $avatar_url; ?>" alt="Top Supporter Avatar">
                    <div class="top-supporter-details">
                        <strong><?= html_escape($username); ?></strong>
                        <span>Spent the most this month.</span>
                    </div>
                </div>
            <?php else: ?>
                <p>Jadilah Top Supporter Pertama!</p>
            <?php endif; ?>
        </div>

        <div class="recent-supporters-panel">
            <h3 class="supporter-v2-title">RECENT SUPPORTERS</h3>
            <div class="recent-supporters-avatars">
                <?php if (!empty($recent_supporters)): ?>
                    <?php foreach($recent_supporters as $supporter): ?>
                        <?php
                            // Logika untuk avatar Bedrock
                            $username_supporter = $supporter->player_username;
                            // Ubah menjadi
                            $avatar_url_supporter = 'https://minotar.net/avatar/' . rawurlencode($username_supporter) . '/50';
                            if (strpos($username_supporter, '.') === 0) {
                                $avatar_url_supporter = 'https://minotar.net/avatar/Steve/50';
                            }
                        ?>
                        <div class="recent-supporter-item" 
                             data-tippy-content="<strong><?= html_escape($username_supporter); ?></strong><br>Purchase <?= html_escape($supporter->purchased_items); ?>">
                            <img src="<?= $avatar_url_supporter; ?>" alt="Recent Supporter Avatar">
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Belum ada pembelian terbaru.</p>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <script src="https://unpkg.com/@popperjs/core@2"></script>
    <script src="https://unpkg.com/tippy.js@6"></script>

    <script>
        tippy('[data-tippy-content]', {
            allowHTML: true,
            theme: 'minehive-dark'
        });
    </script>
</div>