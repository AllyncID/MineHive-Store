<h1>Dashboard<span class="filter-title">(<?= $filter_title ?>)</span></h1>
<p>Selamat Datang, <strong><?= html_escape($this->session->userdata('admin_username')); ?></strong>! Berikut adalah ringkasan toko Anda.</p>



<div class="dashboard-filters">
    <a href="<?= base_url('admin/dashboard?range=today'); ?>" class="filter-btn <?= ($current_range == 'today') ? 'active' : '' ?>">Hari Ini</a>
    <a href="<?= base_url('admin/dashboard?range=7days'); ?>" class="filter-btn <?= ($current_range == '7days') ? 'active' : '' ?>">7 Hari Terakhir</a>
    <a href="<?= base_url('admin/dashboard?range=30days'); ?>" class="filter-btn <?= ($current_range == '30days') ? 'active' : '' ?>">30 Hari Terakhir</a>
    <a href="<?= base_url('admin/dashboard?range=all'); ?>" class="filter-btn <?= ($current_range == 'all') ? 'active' : '' ?>">Semua Waktu</a>
</div>
<div class="stat-cards-container">
    <div class="stat-card blue">
        <div class="card-icon">
            <i class="fas fa-box-open"></i>
        </div>
        <div class="card-content">
            <span class="card-title">Total Produk</span>
            <span class="card-value"><?= $total_products; ?></span>
        </div>
    </div>

    <div class="stat-card green">
        <div class="card-icon">
            <i class="fas fa-exchange-alt"></i>
        </div>
        <div class="card-content">
            <span class="card-title">Total Transaksi</span>
            <span class="card-value"><?= $total_transactions; ?></span>
        </div>
    </div>

    <div class="stat-card yellow">
        <div class="card-icon">
            <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="card-content">
            <span class="card-title">Total Pendapatan</span>
            <span class="card-value">Rp <?= number_format($total_revenue, 0, ',', '.'); ?></span>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <div class="main-panel">
        <!-- PERUBAHAN DI SINI: Judul sekarang dinamis -->
        <h2>Grafik Penjualan (<?= $filter_title ?>)</h2>
        <div class="chart-container">
            <canvas id="salesChart"></canvas>
        </div>
    </div>
<div class="side-panel">
        <h2>Aktivitas Terbaru</h2>
        <div class="activity-feed">
            <?php if (!empty($recent_transactions)): ?>
                <?php foreach($recent_transactions as $trx): ?>
                    <div class="activity-item">
                        <div class="activity-icon green">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="activity-content">
                            <p>
                                <strong><?= html_escape($trx->player_username); ?></strong> baru saja membeli item senilai 
                                <strong>Rp <?= number_format($trx->grand_total, 0, ',', '.'); ?></strong>
                            </p>
                            <span class="activity-time">
                                <?= date('d M Y, H:i', strtotime($trx->created_at)); ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                    <div class="activity-item">
                        <div class="activity-icon green">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="activity-content">
                            <p>
                                <strong><?= html_escape($trx->player_username); ?></strong> baru saja membeli: 
                                <i><?= html_escape($trx->purchased_items); ?></i>
                            </p>
                            <span class="activity-time">
                                <?= time_ago($trx->created_at); ?>
                            </span>
                        </div>
                    </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="content-card">
    <h3><i class='bx bxs-megaphone'></i> Pengaturan Announcement Bar</h3>
    
    <form action="<?= base_url('admin/dashboard/update_settings'); ?>" method="POST">
        
        <div class="form-group">
            <label for="announcement_bar_enabled">Status Bar</label>
            <select name="announcement_bar_enabled" id="announcement_bar_enabled" class="form-control">
                <option value="1" <?= ($settings['announcement_bar_enabled'] == '1') ? 'selected' : ''; ?>>Aktif (Tampilkan)</option>
                <option value="0" <?= ($settings['announcement_bar_enabled'] == '0') ? 'selected' : ''; ?>>Tidak Aktif (Sembunyikan)</option>
            </select>
        </div>

        <div class="form-group">
            <label for="announcement_bar_text">Teks Pengumuman</label>
            <input type="text" name="announcement_bar_text" id="announcement_bar_text" class="form-control" value="<?= html_escape($settings['announcement_bar_text']); ?>" placeholder="Cth: Diskon 20% untuk semua rank!">
        </div>

        <div class="form-group">
            <label for="announcement_bar_link">Tautan (Opsional)</label>
            <input type="text" name="announcement_bar_link" id="announcement_bar_link" class="form-control" value="<?= html_escape($settings['announcement_bar_link']); ?>" placeholder="Cth: store/show/survival/ranks">
            <small>Jika diisi, bar akan bisa diklik. Kosongkan jika tidak perlu.</small>
        </div>

        <div class="form-group">
            <label for="announcement_timer_end">Waktu Berakhir Timer (Opsional)</label>
            <input type="text" name="announcement_timer_end" id="announcement_timer_end" class="form-control flatpickr-datetime" value="<?= html_escape($settings['announcement_timer_end']); ?>" placeholder="YYYY-MM-DD HH:MM:SS">
            <small>Format: Tahun-Bulan-Tanggal Jam:Menit. Kosongkan jika tidak ingin ada timer.</small>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary"><i class='bx bxs-save'></i> Simpan Pengaturan</button>
        </div>

    </form>
</div>

<!-- Card Pengaturan Promo Popup -->
<div class="content-card">
    <h3><i class='bx bxs-gift'></i> Pengaturan Promo Popup</h3>
    
    <form action="<?= base_url('admin/dashboard/update_promo_popup'); ?>" method="POST">
        
        <div class="form-group">
            <label for="is_enabled">Status Popup</label>
            <select name="is_enabled" id="is_enabled" class="form-control">
                <option value="1" <?= (isset($promo_popup['is_enabled']) && $promo_popup['is_enabled'] == '1') ? 'selected' : ''; ?>>Aktif (Tampilkan di Store)</option>
                <option value="0" <?= (isset($promo_popup['is_enabled']) && $promo_popup['is_enabled'] == '0') ? 'selected' : ''; ?>>Tidak Aktif (Sembunyikan)</option>
            </select>
        </div>

        <div class="form-group">
            <label for="title">Judul Popup</label>
            <input type="text" name="title" id="title" class="form-control" value="<?= isset($promo_popup['title']) ? html_escape($promo_popup['title']) : ''; ?>" placeholder="Cth: Promo Bonus Top Up!">
        </div>

        <div class="form-group">
            <label for="promo_tier_1">Tier 1</label>
            <input type="text" name="promo_tier_1" id="promo_tier_1" class="form-control" value="<?= isset($promo_popup['promo_tier_1']) ? html_escape($promo_popup['promo_tier_1']) : ''; ?>" placeholder="Cth: 49K - 99K akan mendapatkan bonus...">
        </div>
        
        <div class="form-group">
            <label for="promo_tier_2">Tier 2</label>
            <input type="text" name="promo_tier_2" id="promo_tier_2" class="form-control" value="<?= isset($promo_popup['promo_tier_2']) ? html_escape($promo_popup['promo_tier_2']) : ''; ?>" placeholder="Cth: 100K - 149K akan mendapatkan bonus...">
        </div>

        <div class="form-group">
            <label for="promo_tier_3">Tier 3</label>
            <input type="text" name="promo_tier_3" id="promo_tier_3" class="form-control" value="<?= isset($promo_popup['promo_tier_3']) ? html_escape($promo_popup['promo_tier_3']) : ''; ?>" placeholder="Cth: 150K - 199K akan mendapatkan bonus...">
        </div>

        <div class="form-group">
            <label for="promo_tier_4">Tier 4</label>
            <input type="text" name="promo_tier_4" id="promo_tier_4" class="form-control" value="<?= isset($promo_popup['promo_tier_4']) ? html_escape($promo_popup['promo_tier_4']) : ''; ?>" placeholder="Cth: 200K - 249K akan mendapatkan bonus...">
        </div>

        <div class="form-group">
            <label for="promo_tier_5">Tier 5</label>
            <input type="text" name="promo_tier_5" id="promo_tier_5" class="form-control" value="<?= isset($promo_popup['promo_tier_5']) ? html_escape($promo_popup['promo_tier_5']) : ''; ?>" placeholder="Cth: Diatas 250K akan mendapatkan bonus...">
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary"><i class='bx bxs-save'></i> Simpan Pengaturan Popup</button>
        </div>

    </form>
</div>


<script>
    // Memastikan script berjalan setelah halaman sepenuhnya dimuat
    document.addEventListener('DOMContentLoaded', function () {
        // Cari elemen canvas berdasarkan ID-nya
        const ctx = document.getElementById('salesChart');

        // Jangan jalankan jika elemen canvas tidak ditemukan
        if (ctx) {
            new Chart(ctx, {
                type: 'line', // Tipe grafik adalah garis
                data: {
                    labels: <?= $chart_labels; ?>, // Label tanggal dari controller
                    datasets: [{
                        label: 'Pendapatan Harian (Rp)',
                        data: <?= $chart_data; ?>, // Data penjualan dari controller
                        fill: true,
                        backgroundColor: 'rgba(249, 181, 54, 0.2)', // Warna area di bawah garis (Kuning transparan)
                        borderColor: 'rgba(249, 181, 54, 1)',     // Warna garis (Kuning pekat)
                        pointBackgroundColor: 'rgba(249, 181, 54, 1)',
                        pointBorderColor: '#fff',
                        pointHoverRadius: 7,
                        pointHoverBackgroundColor: '#fff',
                        pointHoverBorderColor: 'rgba(249, 181, 54, 1)',
                        tension: 0.3 // Membuat garis sedikit melengkung (tidak kaku)
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                // Format angka di sumbu Y menjadi 'Rp ...'
                                callback: function(value, index, values) {
                                    return 'Rp ' + new Intl.NumberFormat('id-ID').format(value);
                                }
                            }
                        }
                    },
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    });
</script>