<h1>Manage Products</h1>
<p>Kelola semua produk yang dijual di toko Anda.</p>
<a href="<?= base_url('admin/products/add'); ?>" class="btn btn-primary" style="margin-bottom: 20px; display: inline-block;"><i class="fas fa-plus"></i> Tambah Produk Baru</a>

<div class="dashboard-filters" style="margin-bottom: 25px;">
    <?php 
        $realms = ['all', 'survival', 'skyblock', 'acidisland']; // Definisikan realm Anda
    ?>
    <?php foreach($realms as $realm): ?>
        <a href="<?= base_url('admin/products?realm=' . $realm); ?>" 
           class="filter-btn <?= ($current_filter == $realm) ? 'active' : '' ?>">
           <?= ucfirst($realm); ?>
        </a>
    <?php endforeach; ?>
</div>

<?php if($this->session->flashdata('success')): ?>
    <p style="color:green;"><?= $this->session->flashdata('success'); ?></p>
<?php endif; ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>LuckPerms Group</th> <th>Realm</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $product): ?>
        <tr>
            <td><?= html_escape($product->id); ?></td>
            <td><?= html_escape($product->name); ?></td>
            
            <td>
                <?php
                    // Tampilkan grup jika ada, jika tidak (misal untuk tipe currency), tampilkan strip (-)
                    echo !empty($product->luckperms_group) ? html_escape($product->luckperms_group) : '-';
                ?>
            </td>

            <td><?= html_escape($product->realm); ?></td>
            <td>Rp <?= number_format($product->price, 0, ',', '.'); ?></td>
            <td>
                <a href="<?= base_url('admin/products/edit/' . $product->id); ?>" class="btn btn-secondary">Edit</a>
                <a href="<?= base_url('admin/products/duplicate/' . $product->id); ?>" class="btn btn-info" style="background-color: var(--accent-blue);" onclick="return confirm('Yakin ingin menduplikasi produk ini?');">Duplikat</a>
                <a href="<?= base_url('admin/products/delete/' . $product->id); ?>" class="btn btn-danger" style="background-color: var(--accent-pink);" onclick="return confirm('Yakin ingin menghapus produk ini?');">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>