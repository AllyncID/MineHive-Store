<?php
// [FITUR] Siapkan data untuk mode edit
$is_edit = isset($product);
$current_product_type = $is_edit ? $product->product_type : 'rank';
$current_category = $is_edit ? $product->category : 'ranks'; // Ambil kategori saat ini

// [FITUR] Siapkan data untuk bundle
$bundle_product_ids = [];
if ($is_edit && $current_product_type == 'bundles' && !empty($product->description)) {
    $bundle_product_ids = json_decode($product->description, true);
    if (!is_array($bundle_product_ids)) {
        $bundle_product_ids = [];
    }
}
?>

<h1><?= $is_edit ? 'Edit' : 'Tambah'; ?> Produk</h1>

<div class="form-container">
    <form action="" method="post">
        
        <div class="form-group">
            <label for="product_type">Tipe Produk</label>
            <select id="product_type" name="product_type" required>
                <option value="rank" <?= ($current_product_type == 'rank') ? 'selected' : ''; ?>>Rank</option>
                <option value="currency" <?= ($current_product_type == 'currency') ? 'selected' : ''; ?>>Mata Uang (Currency/Bucks)</option>
                <option value="bundles" <?= ($current_product_type == 'bundles') ? 'selected' : ''; ?>>Bundles (Paket)</option>
            </select>
        </div>

        <div class="form-group">
            <label for="category">Kategori Toko (Untuk Tampilan di Store)</label>
            <select id="category" name="category" required>
                <option value="ranks" <?= ($current_category == 'ranks') ? 'selected' : ''; ?>>Ranks</option>
                <option value="rank_upgrades" <?= ($current_category == 'rank_upgrades') ? 'selected' : ''; ?>>Rank Upgrades</option>
                <option value="currency" <?= ($current_category == 'currency') ? 'selected' : ''; ?>>Currency / Bucks</option>
                <option value="bundles" <?= ($current_category == 'bundles') ? 'selected' : ''; ?>>Bundles</option>
                <!-- [BUG FIX] Menambahkan kategori 'gktau' yang hilang -->
                <option value="gktau" <?= ($current_category == 'gktau') ? 'selected' : ''; ?>>gktau (Lain-lain)</option>
            </select>
        </div>

        <div class="form-group">
            <label for="name">Nama Produk (Cth: [VIP] Rank atau Paket Starter)</label>
            <input type="text" id="name" name="name" value="<?= $is_edit ? html_escape($product->name) : ''; ?>" required>
        </div>

        <!-- [UPDATE] Wrapper untuk field spesifik Tipe Produk -->

        <div id="luckperms-group-wrapper" class="form-group toggleable-field">
            <label for="luckperms_group">LuckPerms Group Identifier (Wajib untuk Rank)</label>
            <input type="text" id="luckperms_group" name="luckperms_group" 
                value="<?= $is_edit ? html_escape($product->luckperms_group ?? '') : ''; ?>" 
                placeholder="Cth: vip, mvp, warden (sesuai nama grup di LuckPerms)">
        </div>

        <div id="description-wrapper" class="form-group toggleable-field">
            <label for="description_simple">Deskripsi Singkat (Untuk Currency)</label>
            <textarea id="description_simple" name="description_simple" rows="4"><?= ($is_edit && $current_product_type == 'currency') ? html_escape($product->description) : ''; ?></textarea>
        </div>
        
        <div id="perks-editor-wrapper" class="form-group toggleable-field">
            <label>Keuntungan / Perks (Untuk Rank)</label>
            <div id="perks-editor">
                <!-- Editor Perks akan di-generate oleh JS di admin_footer.php -->
            </div>
            <!-- [UPDATE] Ganti nama field agar unik -->
            <textarea name="description_perks" id="description_hidden" style="display: none;"><?= ($is_edit && $current_product_type == 'rank') ? html_escape($product->description) : ''; ?></textarea>
        </div>

        <!-- [FITUR BARU] Wrapper untuk Pilihan Isi Bundle -->
        <div id="bundle-items-wrapper" class="form-group toggleable-field">
            <label for="bundle_product_ids">Isi Bundle (Pilih produk yang termasuk)</label>
            <select name="bundle_product_ids[]" id="bundle_product_ids" multiple>
                <option value="">Pilih produk...</option>
                <?php if (isset($all_products) && !empty($all_products)): ?>
                    <?php foreach($all_products as $prod): ?>
                        <?php
                        // Jangan biarkan bundle berisi dirinya sendiri (jika mode edit)
                        if ($is_edit && $prod->id == $product->id) continue;
                        
                        // --- [PERUBAHAN DI SINI] ---
                        // Baris ini saya nonaktifkan (comment) agar produk bundle lain bisa dipilih
                        // if ($prod->product_type == 'bundles') continue; 
                        
                        // [BUG FIX] Buat data-text untuk TomSelect search
                        $option_text = html_escape($prod->name) . ' (' . html_escape(ucfirst($prod->realm)) . ')';
                        ?>
                        <option value="<?= $prod->id; ?>" 
                                data-text="<?= $option_text; ?>"
                                <?= in_array($prod->id, $bundle_product_ids) ? 'selected' : ''; ?>>
                            [<?= html_escape(ucfirst($prod->realm)); ?>] <?= html_escape($prod->name); ?>
                        </option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
            <small>Pilih semua produk yang akan otomatis ditambahkan ke keranjang saat bundle ini dibeli.</small>
        </div>

        <!-- Akhir Wrapper -->

        <div class="form-group">
            <label for="price">Harga Jual (Harga Total)</label>
            <input type="number" id="price" name="price" value="<?= $is_edit ? $product->price : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="original_price">Harga Asli (Total harga asli item jika dibeli satuan, untuk efek coret)</label>
            <input type="number" id="original_price" name="original_price" value="<?= $is_edit ? $product->original_price : ''; ?>">
        </div>
        <div class="form-group">
            <label for="realm">Realm (Pilih realm utama untuk produk ini)</label>
            <input type="text" id="realm" name="realm" value="<?= $is_edit ? html_escape($product->realm) : ''; ?>" required>
        </div>
         <div class="form-group">
            <label for="image_url">URL Gambar (Gunakan gambar custom untuk bundle)</label>
            <input type="text" id="image_url" name="image_url" value="<?= $is_edit ? html_escape($product->image_url) : ''; ?>">
        </div>
        <div class="form-group">
            <label for="command">Perintah (Command) (Opsional untuk Bundle)</label>
            <input type="text" id="command" name="command" value="<?= $is_edit ? html_escape($product->command) : ''; ?>">
            <small>Kosongkan jika bundle tidak memberi command tambahan. Sistem akan otomatis menjalankan command dari tiap item di dalamnya.</small>
        </div>
        
        <div class="form-group">
            <label for="is_active">Status Produk</label>
            <select id="is_active" name="is_active" class="form-control">
                <option value="1" <?= ($is_edit && $product->is_active == 1) ? 'selected' : ''; ?>>
                    Aktif (Tampil di Toko)
                </option>
                <option value="0" 
                    <?php 
                        if ($is_edit && $product->is_active == 0) {
                            echo 'selected';
                        } elseif (!$is_edit) { // Default ke Non-Aktif (Draft) untuk produk baru
                            echo 'selected';
                        }
                    ?>>
                    Non-Aktif (Draft)
                </option>
            </select>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Simpan Produk</button>
            <a href="<?= base_url('admin/products'); ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<!-- [PERBAIKAN] Tambahkan style di sini untuk atasi bug transparan -->
<style>
    /* Perbaikan untuk TomSelect transparan */
    .ts-dropdown {
        z-index: 1050 !important; /* Pastikan di atas elemen form lain */
        /* Ganti warna background solid (sesuai tema admin.css) */
        background-color: #1E180E; 
        border: 1px solid rgb(43, 36, 21);
    }
    .ts-dropdown .ts-option {
        padding: 10px 15px; /* Sedikit padding agar rapi */
    }
    .ts-dropdown .ts-option.active {
        background-color: #1A150C; /* Warna hover/active */
        color: #FFFFFF;
    }
</style>

<!-- [UPDATE] Tambahkan TomSelect untuk Bundle -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const typeSelector = document.getElementById('product_type');
    const luckpermsWrapper = document.getElementById('luckperms-group-wrapper');
    const descriptionWrapper = document.getElementById('description-wrapper');
    const perksWrapper = document.getElementById('perks-editor-wrapper');
    const bundleWrapper = document.getElementById('bundle-items-wrapper'); // [BARU]

    // [BUG FIX] Inisialisasi TomSelect untuk bundle dengan render kustom
    if (document.getElementById('bundle_product_ids')) {
        new TomSelect('#bundle_product_ids', {
            plugins: ['remove_button'],
            placeholder: 'Cari dan pilih produk...',
            // [BUG FIX] Tambahkan ini agar search-nya bener
            searchField: ['text'], // Cari berdasarkan teks opsi
            // [BUG FIX] Render kustom untuk tampilan yang lebih bersih di dropdown
            render: {
                option: function(data, escape) {
                    // Ambil teks dari atribut data-text yang kita buat di PHP
                    var text = data.text; 
                    // Ganti format [Realm] Nama Produk menjadi Nama Produk (Realm)
                    var match = text.match(/\[(.*?)\] (.*)/);
                    if (match) {
                        return '<div>' + escape(match[2]) + ' <span style="color: #888; font-size: 0.9em;">(' + escape(match[1]) + ')</span></div>';
                    }
                    return '<div>' + escape(text) + '</div>';
                },
                item: function(data, escape) {
                     var text = data.text;
                     var match = text.match(/\[(.*?)\] (.*)/);
                     if (match) {
                        return '<div>' + escape(match[2]) + ' <span style="color: #aaa;">(' + escape(match[1]) + ')</span></div>';
                    }
                    return '<div>' + escape(text) + '</div>';
                }
            }
        });
    }

    function toggleFields() {
        const selectedType = typeSelector.value;

        // Sembunyikan semua field unik dulu
        luckpermsWrapper.style.display = 'none';
        descriptionWrapper.style.display = 'none';
        perksWrapper.style.display = 'none';
        bundleWrapper.style.display = 'none'; // [BARU]

        // Tampilkan field yang sesuai
        if (selectedType === 'rank') {
            luckpermsWrapper.style.display = 'block';
            perksWrapper.style.display = 'block';
        } else if (selectedType === 'currency') {
            descriptionWrapper.style.display = 'block';
        } else if (selectedType === 'bundles') {
            bundleWrapper.style.display = 'block'; // [BARU]
        }
    }

    // Jalankan saat halaman dimuat
    toggleFields();

    // Jalankan setiap kali pilihan tipe produk berubah
    typeSelector.addEventListener('change', toggleFields);

    // --- (Script untuk editor perks masih ada di admin_footer.php dan akan tetap berjalan) ---
    // --- (Script untuk submit form tidak perlu diubah, karena controller sudah diupdate) ---
});
</script>