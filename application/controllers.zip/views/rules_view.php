<div class="rules-wrapper" data-aos="fade-up" data-aos-delay="200">
    <div class="rules-header">
        <h1>Peraturan Server & Komunitas</h1>
        <p>Harap baca dan patuhi semua peraturan untuk menciptakan lingkungan bermain yang nyaman dan adil untuk semua.</p>
    </div>

    <div class="tab-nav">
        <button class="tab-nav-link active" data-tab="server-rules">
            Peraturan Server
        </button>
        <button class="tab-nav-link" data-tab="discord-rules">
            Peraturan Discord
        </button>
    </div>

    <div class="tab-content-wrapper">

    <div id="server-rules" class="tab-pane active" data-aos="fade-up" data-aos-delay="300">
    <div class="content-card">

        <h3>Peraturan Perilaku & Obrolan</h3>
        <ol class="rule-list">
            <li>
                <strong>Spamming & Rioting</strong><br>
                <small><em>Sanksi: Mute 10 Menit - Mute Permanen</em></small><br>
                Jangan mengganggu obrolan dengan pesan berulang atau berlebihan. Berikan jarak minimal 5 menit di antara iklan.
            </li>
            <li>
                <strong>Bahasa & Diskusi Tidak Pantas</strong><br>
                <small><em>Sanksi: Mute 3 Jam - Mute Permanen</em></small><br>
                Tidak ada kata-kata kasar, vulgar, atau topik tidak pantas (politik, ras, agama).
            </li>
            <li>
                <strong>Sarkasme dan Mengejek</strong><br>
                <small><em>Sanksi: Jail, Mute - Ban</em></small><br>
                Tidak ada sarkasme atau pengolokan yang berlebihan dan menyinggung pemain lain.
            </li>
            <li>
                <strong>Menghina Staf & Pemain Lain</strong><br>
                <small><em>Sanksi: Jail, Mute - Ban</em></small><br>
                Jangan melecehkan atau tidak menghormati pemain lain maupun staf yang bertugas. Berkomunikasi dengan sopan dan baik.
            </li>
             <li>
                <strong>Berbohong Kepada Staf</strong><br>
                <small><em>Sanksi: Ban 1 Hari - Permanen</em></small><br>
                Jangan berbohong atau memberikan informasi palsu kepada staf.
            </li>
            <li>
                <strong>Menyebarkan Drama & Hoax</strong><br>
                <small><em>Sanksi: Ban 1 Hari - Permanen</em></small><br>
                Dilarang keras memulai, menyebarkan, atau berpartisipasi dalam drama dan berita bohong yang meresahkan.
            </li>
        </ol>
        
        <h3>Peraturan Gameplay & Fair Play</h3>
        <ol class="rule-list">
            <li>
                <strong>Hacking dan Cheating</strong><br>
                <small><em>Sanksi: Ban 3 Hari - Ban Permanen</em></small><br>
                Tidak ada cheat atau modifikasi klien yang memberikan keuntungan tidak adil dalam permainan (contoh: Killaura, Fly, X-Ray).
            </li>
            <li>
                <strong>Mencuri & Griefing</strong><br>
                <small><em>Sanksi: Jail 3 Jam - Ban Permanen</em></small><br>
                Jangan mencuri item atau merusak properti/bangunan milik pemain lain tanpa izin.
            </li>
             <li>
                <strong>Menyalahgunakan Bug Game</strong><br>
                <small><em>Sanksi: Jail - Ban Permanen</em></small><br>
                Dilarang dengan sengaja memanfaatkan bug atau glitch untuk keuntungan pribadi, termasuk duplikasi item.
            </li>
            <li>
                <strong>Cross-Teaming & Team Killing</strong><br>
                <small><em>Sanksi: Jail/Ban 1 Hari - Ban Permanen</em></small><br>
                Dilarang bekerja sama dengan tim lawan (cross-team) atau membunuh/merugikan teman satu tim (team-kill/grief).
            </li>
            <li>
                <strong>Penyalahgunaan Multi-Akun (Boosting)</strong><br>
                <small><em>Sanksi: Jail/Ban Sementara pada akun tambahan & Reset statistik akun utama</em></small><br>
                Setiap pemain diizinkan memiliki maksimal 3 akun per alamat IP. Namun, dilarang keras menggunakan akun tambahan untuk memberikan keuntungan tidak adil pada akun utama, seperti menaikkan statistik di papan peringkat (leaderboard boosting) atau mentransfer keuntungan secara tidak wajar.
            </li>
            <li>
                <strong>Penggunaan Bot & Otomatisasi</strong><br>
                <small><em>Sanksi: Mute Permanen - Ban Permanen</em></small><br>
                Dilarang menggunakan bot, seperti auto-chat atau skrip otomatisasi lain yang dapat menyebabkan ketidakseimbangan gameplay. Sanksi akan tetap berlaku hingga bot tersebut dilepas dan tidak digunakan lagi.
            </li>
            <li>
                <strong>Perangkap Pembunuhan (Kill Trap)</strong><br>
                <small><em>Sanksi: Jail - Ban Permanen</em></small><br>
                Dilarang membuat, menggunakan, atau menjebak pemain lain ke dalam perangkap yang dirancang untuk membunuh mereka secara otomatis atau tanpa perlawanan.
            </li>
        </ol>

        <h3>Peraturan Teknis & Bangunan</h3>
        <ol class="rule-list">
            <li>
                <strong>Penggunaan Redstone yang Efisien</strong><br>
                <small><em>Sanksi: Ban dan Area akan dibersihkan jika tidak diperbaiki</em></small><br>
                Jangan menggunakan rangkaian redstone yang menyebabkan lag, seperti clock yang terlalu cepat atau farm yang tidak efisien. Nonaktifkan jika tidak digunakan.
            </li>
            <li>
                <strong>Bangunan & Gambar Tidak Pantas</strong><br>
                <small><em>Sanksi: Dihapus dan Jail - Ban 3 Hari</em></small><br>
                Dilarang membuat bangunan atau gambar (map art) yang bersifat ofensif, vulgar, atau tidak pantas.
            </li>
        </ol>

        <h3>Pelanggaran Serius</h3>
        <ol class="rule-list">
            <li>
                <strong>Ancaman & Dorongan Bunuh Diri</strong><br>
                <small><em>Sanksi: Jail - Ban Permanen</em></small><br>
                Mengancam atau mendorong tindakan yang merugikan diri sendiri atau orang lain tidak akan ditoleransi.
            </li>
            <li>
                <strong>Transaksi Uang Nyata (RMT)</strong><br>
                <small><em>Sanksi: Ban Permanen</em></small><br>
                Dilarang melakukan transaksi jual/beli item, akun, atau jasa apa pun menggunakan uang nyata.
            </li>
             <li>
                <strong>Menghindari Sanksi</strong><br>
                <small><em>Sanksi: Ban Permanen</em></small><br>
                Dilarang menghindari sanksi dengan membuat akun baru atau menggunakan IP yang berbeda.
            </li>
            <li>
                <strong>Menyinggung SARA & Orang Tua</strong><br>
                <small><em>Sanksi: Jail - Ban Permanen</em></small><br>
                Dilarang keras menyinggung Suku, Agama, Ras, Negara, atau menghina orang tua pemain lain.
            </li>
             <li>
                <strong>Menyebarkan Informasi Pribadi (Doxing)</strong><br>
                <small><em>Sanksi: Ban Permanen - IP Ban</em></small><br>
                Dilarang menyebarkan informasi pribadi pemain lain tanpa izin, seperti nama asli, foto, alamat, atau media sosial.
            </li>
            <li>
                <strong>Pornografi & Pedofilia</strong><br>
                <small><em>Sanksi: Ban Permanen - IP Ban</em></small><br>
                Segala bentuk konten yang berhubungan dengan pornografi atau pedofilia akan langsung ditindak tegas.
            </li>
            <li>
                <strong>Pelanggaran Terkait UU ITE</strong><br>
                <small><em>Sanksi: Ban Permanen</em></small><br>
                Dilarang melakukan aktivitas apa pun yang melanggar Undang-Undang Informasi dan Transaksi Elektronik (UU ITE) yang berlaku di Indonesia.
            </li>
        </ol>
    <p style="text-align: left; color: var(--text-secondary); margin-top: 30px; font-style: italic;">
        <strong>Catatan:</strong> Durasi sanksi yang tercantum adalah perkiraan standar. Staf berhak menyesuaikan (menambah atau mengurangi) durasi hukuman berdasarkan tingkat keparahan pelanggaran dan riwayat pemain.
    </p>
    </div>
</div>

<div id="discord-rules" class="tab-pane">
    <div class="content-card">

        <h3>Peraturan Komunikasi & Perilaku</h3>
        <ol class="rule-list">
            <li>
                <strong>Dilarang Spam & Flooding</strong><br>
                Jangan mengirim pesan berulang atau berlebihan. Promosi atau iklan harus memiliki jeda minimal 5 menit. Dilarang menggunakan bot untuk spam.
            </li>
            <li>
                <strong>Bahasa & Diskusi yang Pantas</strong><br>
                Dilarang menggunakan kata-kata kasar, vulgar, atau membahas topik sensitif seperti politik, ras, dan agama.
            </li>
            <li>
                <strong>Hormati Semua Anggota & Staf</strong><br>
                Jangan melecehkan, mengintimidasi, merendahkan, atau melakukan sarkasme yang menyakiti anggota lain. Keputusan staf bersifat final dan wajib dipatuhi.
            </li>
            <li>
                <strong>Dilarang Ping & Tag Berlebihan</strong><br>
                Jangan melakukan spam ping/tag kepada anggota atau staf tanpa alasan yang jelas dan penting.
            </li>
             <li>
                <strong>Dilarang Memulai Drama & Menyebar Hoax</strong><br>
                Jangan menyebarkan berita palsu atau memicu drama yang dapat mengganggu kenyamanan komunitas.
            </li>
        </ol>

        <h3>Peraturan Konten & Tautan</h3>
        <ol class="rule-list">
            <li>
                <strong>Dilarang Promosi Tanpa Izin</strong><br>
                Dilarang mempromosikan server lain, media sosial pribadi, atau bisnis apa pun tanpa izin dari Admin.
            </li>
            <li>
                <strong>Dilarang Konten NSFW & Tidak Pantas</strong><br>
                Dilarang membagikan konten yang mengandung unsur dewasa (NSFW), kekerasan grafis, atau hal tidak pantas lainnya.
            </li>
            <li>
                <strong>Dilarang Scamming & Phishing</strong><br>
                Dilarang melakukan segala bentuk penipuan atau membagikan tautan berbahaya yang bertujuan mencuri data.
            </li>
             <li>
                <strong>Dilarang Menyebarkan Informasi Pribadi</strong><br>
                Dilarang menyebarkan informasi pribadi (doxing) milik orang lain tanpa izin eksplisit dari yang bersangkutan.
            </li>
        </ol>

        <h3>Peraturan Akun & Teknis</h3>
        <ol class="rule-list">
             <li>
                <strong>Patuhi Ketentuan Layanan Discord</strong><br>
                Semua aktivitas di dalam server ini harus mematuhi <a href="https://discord.com/terms" target="_blank" rel="noopener noreferrer">Terms of Service</a> dan <a href="https://discord.com/guidelines" target="_blank" rel="noopener noreferrer">Community Guidelines</a> dari Discord.
            </li>
            <li>
                <strong>Dilarang Jual/Beli dengan Uang Nyata</strong><br>
                Dilarang menjual atau membeli akun, item in-game, atau jasa apa pun yang melibatkan transaksi uang nyata.
            </li>
            <li>
                <strong>Penyalahgunaan Multi-Akun</strong><br>
                Maksimal 3 akun per pengguna. Dilarang keras menggunakan akun tambahan untuk menghindari sanksi (mute/ban).
            </li>
            <li>
                <strong>Dilarang Membahas Cheat & Eksploit</strong><br>
                Tidak boleh membahas, membagikan, atau meminta cheat, hack, atau cara menyalahgunakan bug game di server ini.
            </li>
             <li>
                <strong>Penggunaan Bot yang Wajar</strong><br>
                Gunakan bot (misal: bot musik) sesuai fungsinya dan jangan disalahgunakan untuk spam atau mengganggu anggota lain.
            </li>
        </ol>
        
        <h3>Sistem Sanksi</h3>
        <ul class="rule-list" style="list-style-type: square; padding-left: 25px;">
             <li><strong>Pelanggaran Ringan:</strong> Peringatan lisan atau Mute sementara.</li>
             <li><strong>Pelanggaran Sedang:</strong> Timeout atau Mute untuk durasi yang lebih lama.</li>
             <li><strong>Pelanggaran Berat:</strong> Ban sementara atau Ban permanen dari server.</li>
        </ul>
        <p style="margin-top: 25px;">Harap patuhi semua aturan ini untuk menciptakan komunitas yang nyaman, aman, dan menyenangkan bagi semua anggota. Terima kasih!</p>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabLinks = document.querySelectorAll('.tab-nav-link');
    const tabPanes = document.querySelectorAll('.tab-pane');

    tabLinks.forEach(link => {
        link.addEventListener('click', () => {
            const tabId = link.getAttribute('data-tab');

            tabLinks.forEach(item => item.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));

            link.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
});
</script>