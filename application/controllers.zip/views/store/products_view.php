<div class="container">
    
    <div class="page-header">
        <a href="<?= base_url(''); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
        <h1>
            <?= html_escape(strtoupper($realm_name)); ?> 
            <?php 
                // Menggunakan variabel $category yang DIKIRIM dari Controller, bukan dari URL.
                // Ini lebih aman dan sesuai dengan pola MVC.
                echo strtoupper(str_replace('_', ' ', html_escape($category)));
            ?>
        </h1>
        <a href="#" class="btn btn-secondary more-info"><i class="fas fa-info-circle"></i> More Info</a>
    </div>

    <div class="product-grid">
        <?php if (empty($products)): ?>
            <p>Belum ada produk untuk kategori ini.</p>
        <?php else: ?>
            <?php foreach ($products as $product): ?>
                <div class="product-card-v2">
                    <div class="product-image">
                        <img src="<?= html_escape($product['image_url']); ?>" alt="<?= html_escape($product['name']); ?>">
                    </div>
                    <div class="product-details">
                        <h3 class="product-title"><?= html_escape($product['name']); ?></h3>
                        <div class="product-price">
                            <?= number_format($product['final_price'], 0, ',', '.'); ?><span>IDR</span>
                            
                            <?php if(isset($product['discount_percentage'])): ?>
                                <span class="original-price">
                                    <s><?= number_format($product['original_price'], 0, ',', '.'); ?> IDR</s>
                                </span>
                                <span class="discount-badge"><?= $product['discount_percentage']; ?>% OFF</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
<?php
                    // --- LOGIKA KEPEMILIKAN DENGAN HIERARKI ---
                    $is_owned = false;
                    
                    // 1. Pengecekan hanya berjalan jika kita berada di halaman kategori 'rank_upgrades'
                    if ($category == 'rank_upgrades') {
                        
                        // 2. Cek apakah pemain punya rank dan produk ini adalah rank yang ada di hierarki
                        if (!empty($current_rank) && isset($rank_hierarchy[$current_rank]) && isset($product['luckperms_group']) && isset($rank_hierarchy[$product['luckperms_group']])) {

                            // 3. Ambil "bobot" dari rank pemain dan rank produk
                            $player_rank_weight = $rank_hierarchy[$current_rank];
                            $product_rank_weight = $rank_hierarchy[$product['luckperms_group']];

                            // 4. Jika bobot rank pemain LEBIH BESAR atau SAMA DENGAN bobot rank produk, maka dianggap dimiliki.
                            if ($player_rank_weight >= $product_rank_weight) {
                                $is_owned = true;
                            }
                        }
                    }
                    ?>
                    
                    <div class="product-actions">
                        <button class="btn-info js-show-perks" 
                                data-product-id="<?= html_escape($product['id']); ?>"
                                title="Lihat Keuntungan">
                            <i class="fas fa-question"></i>
                        </button>

                        <?php if ($is_owned): ?>
                            <a class="btn-add-to-cart" disabled>OWNED</a>
                        <?php else: ?>
                            <a href="<?= base_url('cart/add/' . $product['id'] . '/' . $category); ?>" class="btn-add-to-cart">ADD TO CART</a>
                        <?php endif; ?>

                    </div>

                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

</div> 
<script>
    // Membuat sebuah object JavaScript
    window.productPerks = {
        <?php
        if (!empty($products)) {
            $product_count = count($products);
            $i = 0;
            foreach ($products as $product) {
                $i++;
                // Pastikan deskripsi tidak kosong dan merupakan JSON yang valid
                $description_json = (!empty($product['description']) && json_decode($product['description']) !== null) ? $product['description'] : '{}';
                echo '"' . html_escape($product['id']) . '": ' . $description_json . (($i < $product_count) ? ',' : '');
            }
        }
        ?>
    };

    // LAPORAN STATUS: Memberi tahu kita di console bahwa objek sudah dibuat
    console.log("SUCCESS: 'Kamus Data' (window.productPerks) telah dibuat di products_view.php. Isinya:", window.productPerks);
</script>