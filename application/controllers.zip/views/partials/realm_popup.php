<div class="popup-overlay" id="realmPopup">
    <div class="popup-container realm-popup-container-v2">
        <span class="popup-close" onclick="hidePopup(this.closest('.popup-overlay'))">&times;</span>

        <div class="popup-header realm-popup-header-v2">
            <h2 class="popup-title">SELECT YOUR REALM</h2>
            <p class="popup-subtitle">CHOOSE YOUR REALM</p>
        </div>

        <div class="popup-body">
<div class="realm-grid-v2">
    <a href="#" class="realm-card-v2" data-base-href="<?= base_url('survival'); ?>">
        <div class="realm-card-bg-v2" style="background-image: url('https://i.imgur.com/nwvK5M2.png'); ?>');"></div>
        <div class="realm-card-overlay-v2"></div>
        <div class="realm-card-title-subtitle-card">
        <h3 class="realm-card-title-v2">SURVIVAL</h3>
        <p class="realm-card-subtitle">Click to view products</p>
        </div>
    </a>

    <a href="#" class="realm-card-v2" data-base-href="<?= base_url('skyblock'); ?>">
        <div class="realm-card-bg-v2" style="background-image: url('https://i.imgur.com/bFFGxIM.png');"></div>
        <div class="realm-card-overlay-v2"></div>
        <div class="realm-card-title-subtitle-card">
        <h3 class="realm-card-title-v2">SKYBLOCK</h3>
        <p class="realm-card-subtitle">Click to view products</p>
        </div>
    </a>

</div>
        </div>
    </div>
</div>