</div> 

    </div> 
    <div class="container footer-section">
        <div class="info-footer-container">
            <div class="info-column">
                <h3>Want to join the fun?</h3>
                <p>
                    Jelajahi dunia MineHive yang luas bersama komunitas pemain yang aktif dan ramah. Bangun, bertualang, dan taklukkan semua tantangan bersama teman-teman barumu.
                </p>
                <p>
                    Ikuti berbagai event seru dengan hadiah eksklusif yang selalu kami siapkan. Jangan tunda lagi, petualangan terbaikmu dimulai di sini, sekarang juga!
                </p>
            </div>
            <div class="info-column">
                <h3>Support MineHive</h3>
                <p>Dukungan Anda membantu kami untuk terus berkembang, menambahkan fitur baru, dan menjaga server tetap berjalan dengan lancar untuk semua pemain.</p>
                <a href="https://discord.gg/minehive" target="_blank" class="btn btn-discord">
                    <img src="<?= base_url('assets/images/discord.svg'); ?>" alt="Discord Icon">
                    Join our Discord
                </a>
            </div>
        </div>
    </div>







<?php if (isset($promo_popup) && $promo_popup['is_enabled'] == 1 && !empty($promo_popup['title'])):
// We check if promo_popup data exists, is enabled, and has a title before rendering
?>
<div id="promoPopupOverlay" class="popup-overlay active">
    <div class="popup-content">
        <span class="popup-close-btn">&times;</span>
        <h2><?= html_escape($promo_popup['title']); ?></h2>
        <ul class="promo-tiers-list">
            <?php if (!empty($promo_popup['promo_tier_1'])): ?>
                <li><?= html_escape($promo_popup['promo_tier_1']); ?></li>
            <?php endif; ?>
            <?php if (!empty($promo_popup['promo_tier_2'])): ?>
                <li><?= html_escape($promo_popup['promo_tier_2']); ?></li>
            <?php endif; ?>
            <?php if (!empty($promo_popup['promo_tier_3'])): ?>
                <li><?= html_escape($promo_popup['promo_tier_3']); ?></li>
            <?php endif; ?>
            <?php if (!empty($promo_popup['promo_tier_4'])): ?>
                <li><?= html_escape($promo_popup['promo_tier_4']); ?></li>
            <?php endif; ?>
            <?php if (!empty($promo_popup['promo_tier_5'])): ?>
                <li><?= html_escape($promo_popup['promo_tier_5']); ?></li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php endif; ?>

<div id="perksPopup" class="popup-overlay scrollbar-transparent">
    <div class="popup-content scrollbar-transparent">
        <h2 id="perksPopupTitle"></h2>
        <ul id="perksPopupList" class="perks-list scrollbar-transparent">
            </ul>
    </div>
    
</div>

<!-- ===== [BARU] STRUKTUR HTML SOCIAL PROOF POPUP ===== -->
<div id="socialProofPopup" class="social-proof-popup">
    <div class="avatar">
        <!-- Avatar akan diisi oleh JS -->
        <img id="socialProofAvatar" src="https://minotar.net/avatar/Steve/40" alt="Avatar">
    </div>
    <div class="content">
        <!-- Teks akan diisi oleh JS -->
        <p id="socialProofText"></p>
    </div>
</div>
<!-- =============================================== -->


<div id="loading-overlay" class="loading-overlay">
        <div class="spinner"></div>
    </div>

    <?php $this->load->view('partials/login_popup'); ?>
    <?php $this->load->view('partials/realm_popup'); // Anda juga bisa memuat popup lain di sini agar rapi ?>

<!-- [FITUR BARU] HTML untuk Popup Kartu Gosok -->
<div class="popup-overlay" id="scratchCardPopup">
    <div class="popup-container scratch-card-container">
        <!-- Tombol Close tidak ada, sengaja biar user fokus -->
        <div class="popup-header scratch-header">
             <h2 class="popup-title" id="scratchCardTitle">Kamu Dapat Hadiah!</h2>
             <p class="popup-subtitle" id="scratchCardSubtitle">Gosok kartu di bawah untuk melihat hadiahmu!</p>
        </div>
        
        <div class="popup-body scratch-body">
            <!-- Area untuk menggosok -->
            <div id="scratchCardCanvasContainer" class="scratch-card-canvas">
                <!-- Hasil (teks) ada di BAWAH canvas -->
                <div id="scratchCardResult" class="scratch-card-result">
                    <i class='bx bxs-gift'></i>
                    <h3 id="scratchCardResultName">Hadiahnya Adalah...</h3>
                    <p id="scratchCardResultValue"></p>
                    <button id="scratchCardCopyButton" class_exists="btn btn-primary" style="display:none;">Salin Kode</button>
                </div>
            </div>
            
            <!-- Tombol Selesai (muncul setelah digosok) -->
            <button id="scratchCardDoneButton" class="btn btn-secondary" style="display:none; margin-top: 20px;">Mantap, Tutup!</button>
        </div>
    </div>
</div>
<!-- [AKHIR FITUR BARU] -->


<script>
    const BASE_URL = "<?= base_url(); ?>";
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/scratchcard-js@1.5.0/dist/scratchcard.min.js"></script> 


<script src="<?= base_url('assets/js/script.js?v=V1.11' . filemtime('assets/js/script.js')); ?>"></script>

<script>
    // Inisialisasi flatpickr (hanya akan berjalan jika ada elemennya di halaman admin)
    if(document.querySelector(".flatpickr-datetime")) {
        flatpickr(".flatpickr-datetime", {
            enableTime: true,
            dateFormat: "Y-m-d H:i",
            altInput: true,
            altFormat: "F j, Y at H:i",
        });
    }

    // Notifikasi SweetAlert dari flashdata
<?php if ($this->session->flashdata('success')): ?>
    Swal.fire({
        timer: 2500,
        title: 'Berhasil!',
        text: '<?= $this->session->flashdata('success'); ?>',
        showConfirmButton: false,
        customClass: {
            popup: 'custom-success-popup',
            title: 'custom-success-title',
            htmlContainer: 'custom-success-text',
            icon: 'custom-success-icon'
        },
        backdrop: `rgba(27, 22, 13, 0.85)`
    });
<?php elseif ($this->session->flashdata('error')): ?>
    Swal.fire({
        title: 'Oops...',
        text: '<?= $this->session->flashdata('error'); ?>',
        showConfirmButton: true, // Beri tombol OK agar user bisa membaca error
        confirmButtonText: 'Mengerti',
        customClass: {
            popup: 'custom-error-popup',
            title: 'custom-error-title',
            htmlContainer: 'custom-error-text',
            icon: 'custom-error-icon',
            confirmButton: 'btn btn-secondary' // Gunakan style tombol Anda
        },
        backdrop: `rgba(27, 22, 13, 0.85)`
    });
<?php elseif ($this->session->flashdata('info')): ?>
    Swal.fire({
        title: 'Info',
        text: '<?= $this->session->flashdata('info'); ?>',
        showConfirmButton: true,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'custom-info-popup',
            title: 'custom-info-title',
            htmlContainer: 'custom-info-text',
            icon: 'custom-info-icon',
            confirmButton: 'btn btn-secondary' // Gunakan style tombol Anda
        },
        backdrop: `rgba(27, 22, 13, 0.85)`
    });
<?php endif; ?>

document.addEventListener('DOMContentLoaded', function() {
    
        console.log("Script transisi halaman SUKSES DIMUAT!"); // <-- TAMBAHKAN BARIS INI

    
    const body = document.body;

    // 1. Tampilkan overlay saat link internal diklik
    document.querySelectorAll('a').forEach(link => {
        // Proses hanya link yang mengarah ke domain yang sama, bukan link eksternal atau anchor #
        if (link.hostname === window.location.hostname && 
            link.getAttribute('target') !== '_blank' &&
            !link.href.includes('#') &&
            link.href.indexOf('javascript:') !== 0
           ) {
            
            link.addEventListener('click', function(e) {
                // Jangan langsung pindah halaman
                e.preventDefault(); 
                
                // Tambahkan class 'is-loading' ke body untuk memunculkan overlay
                body.classList.add('is-loading');
                
                // Beri jeda sedikit agar animasi fade-in terlihat sebelum pindah halaman
                setTimeout(() => {
                    window.location.href = this.href;
                }, 300); // jeda 300 milidetik
            });
        }
    });

    // 2. Sembunyikan overlay saat pengguna menekan tombol "Back" di browser
    // Ini untuk mengatasi bug di beberapa browser (terutama Safari)
    window.addEventListener('pageshow', function(event) {
        // event.persisted bernilai true jika halaman dimuat dari cache (back/forward)
        if (event.persisted) {
            body.classList.remove('is-loading');
        }
    });

});
</script>

<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script src="https://cdn.jsdelivr.net/npm/scratchcard-js@1.5.0/dist/scratchcard.min.js"></script>

</body>
</html>