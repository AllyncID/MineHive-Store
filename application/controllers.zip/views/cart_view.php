<!-- ... (Kode sebelum cart summary) ... -->
<?php
    // Cek terlebih dahulu apakah ada item upgrade di dalam keranjang
    $contains_upgrade = false;
    if (!empty($cart['items'])) {
        foreach ($cart['items'] as $item) {
            if (!empty($item['is_upgrade'])) {
                $contains_upgrade = true;
                break; // Jika sudah ketemu satu, hentikan loop
            }
        }
    }
?>
<div class="container">
    <div class="cart-container">
        <h2>Your Cart</h2>

        <?php if (empty($cart) || empty($cart['items'])): ?>
            <p>Keranjang Anda masih kosong.</p>
        <?php else: ?>

            <form action="<?= base_url('payment/checkout'); ?>" method="post">
                <table class="admin-table cart-table">
                     <!-- ... (thead and tbody content remains the same) ... -->
                     <thead>
                         <tr>
                             <th>Produk</th>
                             <th style="text-align: right;">Harga</th>
                             <th style="width: 5%;"></th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php foreach ($cart['items'] as $index => $item): ?>
                         <tr>
                             <td><?= html_escape($item['name']); ?></td>
                             <td style="text-align: right;">
                                 <div class="cart-price">
                                     <?php if (isset($item['original_price']) && $item['price'] < $item['original_price']): ?>
                                         <s class="original-price-cart">Rp <?= number_format($item['original_price'], 0, ',', '.'); ?></s>
                                         <span class="final-price">Rp <?= number_format($item['price'], 0, ',', '.'); ?></span>
                                     <?php else: ?>
                                         <span class="final-price">Rp <?= number_format($item['price'], 0, ',', '.'); ?></span>
                                     <?php endif; ?>
                                 </div>
                             </td>
                             <td style="text-align: center;"><a href="<?= base_url('cart/remove/' . $index); ?>" class="remove-btn" title="Hapus Item">&times;</a></td>
                         </tr>
                         <?php endforeach; ?>
                     </tbody>
                </table>

                <div class="cart-bottom-section">
                    <div class="cart-left-panel">
                        
                        <!-- [MODIFIKASI] Logika Pesan Hasutan/Upsell -->
                        <?php if (isset($first_time_buyer_message) && $first_time_buyer_message): ?>
                            <!-- Pesan untuk Pembeli Pertama -->
                            <div class="cart-upsell-notice" data-aos="fade-up" style="background-color: rgba(249, 181, 54, 0.1); border-color: #F9B536;">
                                <i class="fas fa-solid fa-star" style="color: #F9B536;"></i>
                                <span><?= $first_time_buyer_message; ?></span>
                            </div>
                        <?php endif; // [MODIFIKASI] endif ditambahkan di sini ?>

                        <?php if (isset($upsell_message) && $upsell_message): // [MODIFIKASI] Diubah dari elseif menjadi if ?>
                            <!-- Pesan Upsell Diskon Keranjang (tampil untuk semua, termasuk pembeli pertama jika ada) -->
                            <div class="cart-upsell-notice" data-aos="fade-up">
                                <i class="fas fa-solid fa-money-bill"></i>
                                <span><?= $upsell_message; ?></span>
                            </div>
                        <?php endif; ?>
                        <!-- (AKHIR MODIFIKASI) -->

                         <!-- [PERUBAHAN] Form promo kini hanya menampilkan kode yang sudah terpasang jika ada -->
                         <div class="promo-form-container" id="promo-form-container">
                             <label for="promo_code">Punya Kode Promo / Referral?</label>
                            
                            <!-- [PERUBAHAN] Tampilkan form input jika SALAH SATU (atau kedua) slot masih kosong -->
                            <div class="promo-form" id="promo-input-form" style="<?= (isset($cart['applied_promo']) && isset($cart['applied_referral'])) ? 'display: none;' : 'display: flex;'; ?>">
                                <input type="text" name="promo_code_input" id="promo_code" placeholder="Masukkan kode di sini">
                                <button type="button" id="apply-promo-btn" class="btn btn-secondary btn-apply">Gunakan</button>
                            </div>

                            <!-- [PERUBAHAN] Wrapper untuk kode yang terpasang -->
                            <div id="applied-codes-wrapper">
                                <!-- Tampilkan kode promo yang terpasang -->
                                <?php if (isset($cart['applied_promo'])): ?>
                                    <div class="applied-code-display" id="applied-promo-display">
                                        <span>Promo: <code><?= html_escape($cart['applied_promo']['code']); ?></code></span>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- Tampilkan kode referral yang terpasang -->
                                <?php if (isset($cart['applied_referral'])): ?>
                                    <div class="applied-code-display" id="applied-referral-display">
                                        <span>Referral: <code><?= html_escape($cart['applied_referral']['code']); ?></code></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                         </div>
                         
                         <?php if (!$contains_upgrade): // Tampilkan opsi gift HANYA JIKA TIDAK ADA item upgrade ?>
                             <div class="gift-panel">
                                 <label class="toggle-switch-label" for="is_gift_checkbox">Kirim sebagai Hadiah ?</label>
                                 <label class="toggle-switch">
                                     <input type="checkbox" id="is_gift_checkbox" name="is_gift" value="1">
                                     <span class="slider"></span>
                                 </label>
                                 <div id="gift-recipient-form" class="gift-recipient-form">
                                     <div class="form-group">
                                         <label for="gifting_username">Username Penerima</label>
                                         <input type="text" name="gifting_username" placeholder="Masukkan nama pemain">
                                     </div>
                                 </div>
                             </div>
                         <?php else: // Jika ADA item upgrade, tampilkan pesan peringatan ?>
                             <div class="info-box" style="margin-top: 20px; padding: 15px; background-color: rgba(255, 185, 59, 0.1); border-left: 3px solid #ffb93b; color: #f0f0f0;">
                                 <p style="margin:0; font-size: 14px;">Pemberian hadiah tidak tersedia jika keranjang berisi Rank Upgrades.</p>
                             </div>
                         <?php endif; ?>
                         <?php // ========================================================== ?>
                    </div>
                    <div class="cart-right-panel">
                        <div class="cart-summary">
                            <h3>Ringkasan Belanja</h3>
                            <div class="summary-row">
                                <span>Subtotal</span>
                                <!-- ID DITAMBAHKAN DI SINI -->
                                <span id="summary-subtotal">Rp <?= number_format($cart['subtotal'], 0, ',', '.'); ?></span>
                            </div>

                            <!-- Modifikasi Teks Diskon Keranjang di sini -->
                            <!-- ID DITAMBAHKAN DI SINI -->
                            <div class="summary-row discount" id="summary-cart-discount-row" style="<?= ($cart['cart_discount'] > 0) ? 'display: flex;' : 'display: none;'; ?>">
                                <span>
                                    Diskon Belanja 
                                    <!-- ID DITAMBAHKAN DI SINI -->
                                    <span id="summary-cart-discount-percentage"><?= (isset($cart['applied_cart_discount_tier']) ? (int) $cart['applied_cart_discount_tier']['percentage'] : '0'); ?></span>%
                                </span>
                                <!-- ID DITAMBAHKAN DI SINI -->
                                <span id="summary-cart-discount-amount">- Rp <?= number_format($cart['cart_discount'], 0, ',', '.'); ?></span>
                            </div>
                            <!-- Akhir Modifikasi -->

                            <!-- [PERUBAHAN] Diskon Kode Promo -->
                            <div class="summary-row discount" id="summary-promo-discount-row" style="<?= ($cart['promo_discount'] > 0) ? 'display: flex;' : 'display: none;'; ?>">
                                <span id="summary-promo-discount-text">
                                    Diskon Promo
                                    (<code><?= isset($cart['applied_promo']['code']) ? html_escape($cart['applied_promo']['code']) : ''; ?></code>)
                                </span>
                                <span id="summary-promo-discount-amount">- Rp <?= number_format($cart['promo_discount'], 0, ',', '.'); ?></span>
                            </div>
                            
                            <!-- [PERUBAHAN] Diskon Kode Referral -->
                            <div class="summary-row discount" id="summary-referral-discount-row" style="<?= ($cart['referral_discount'] > 0) ? 'display: flex;' : 'display: none;'; ?>">
                                <span id="summary-referral-discount-text">
                                    Diskon Referral
                                    (<code><?= isset($cart['applied_referral']['code']) ? html_escape($cart['applied_referral']['code']) : ''; ?></code>)
                                </span>
                                <span id="summary-referral-discount-amount">- Rp <?= number_format($cart['referral_discount'], 0, ',', '.'); ?></span>
                            </div>

                            <div class="summary-row total">
                                <span>Grand Total</span>
                                <!-- ID DITAMBAHKAN DI SINI -->
                                <span id="summary-grand-total">Rp <?= number_format($cart['grand_total'], 0, ',', '.'); ?></span>
                            </div>
                            <div class="checkout-btn-container">
                                <button type="submit" class="btn btn-primary btn-large btn-apply" style="width:100%;">Bayar Sekarang</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <!-- ... (Cross-sell section and scripts remain the same) ... -->
    <?php if (!empty($cross_sell_products)): ?>
         <div class="cross-sell-section">
             <!-- ... existing cross-sell code ... -->
             <h3 class="cross-sell-title">Mungkin anda suka</h3>
             <p class="cross-sell-subtitle">Pemain lain sering membeli ini.</p>
             <div class="product-grid">
                 <?php foreach ($cross_sell_products as $product): ?>
                     <div class="product-card-v2" data-aos="fade-up">
                         <!-- ... existing product card code ... -->
                          <div class="product-image">
                              <img src="<?= html_escape($product['image_url']); ?>" alt="<?= html_escape($product['name']); ?>">
                          </div>
                          <div class="product-details">
                              <h3 class="product-title"><?= html_escape($product['name']); ?></h3>
                              <div class="product-price">
                                  <?= number_format($product['final_price'], 0, ',', '.'); ?><span>IDR</span>
                                  <?php if(isset($product['original_price'])): ?>
                                      <span class="original-price">
                                          <s><?= number_format($product['original_price'], 0, ',', '.'); ?> IDR</s>
                                      </span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="product-actions">
                              <button class="btn-info js-show-perks" data-product-id="<?= html_escape($product['id']); ?>" title="Lihat Keuntungan">
                                  <i class="fas fa-question"></i>
                              </button>
                              <a href="<?= base_url('cart/add/' . $product['id']); ?>" class="btn-add-to-cart btn-ripple">
                                  <i class='bx bx-plus'></i>
                                  <span>ADD TO CART</span>
                              </a>
                          </div>
                     </div>
                 <?php endforeach; ?>
             </div>
         </div>
     <?php endif; ?>
</div>

<!-- Style kustom untuk kode yang diterapkan (opsional, tapi disarankan) -->
<style>
.applied-code-display {
    background-color: #241A0F;
    padding: 12px 15px;
    border-radius: 5px;
    color: var(--text-primary);
    font-weight: 500;
    margin-top: 10px;
}
.applied-code-display code {
    background-color: #1B160D;
    padding: 2px 6px;
    border-radius: 3px;
    font-weight: 700;
    color: var(--accent-orange);
}
</style>

<script>
// ... (existing javascript for gift toggle and promo apply) ...
 document.addEventListener('DOMContentLoaded', function() {
     const giftCheckbox = document.getElementById('is_gift_checkbox');
     const giftForm = document.getElementById('gift-recipient-form');
     if (giftCheckbox) {
         giftCheckbox.addEventListener('change', function() {
             giftForm.style.display = this.checked ? 'block' : 'none';
         });
     }
     
     // Logika untuk tombol apply promo SUDAH DIPINDAHKAN ke script.js global
     // Tidak perlu ada di sini lagi agar tidak duplikat
 });
 
 // Membuat objek JavaScript global untuk data perks cross-sell
 window.productPerks = {
     <?php if (!empty($cross_sell_products)): // Pastikan ada produk cross-sell ?>
         <?php $i = 0; foreach ($cross_sell_products as $product): $i++; // Loop produk ?>
             <?php
                // Ambil deskripsi, pastikan valid JSON, jika tidak, anggap objek kosong
                $description_json = (!empty($product['description']) && json_decode($product['description']) !== null) ? $product['description'] : '{}';
             ?>
             "<?= html_escape($product['id']); // Cetak ID produk sebagai key ?>": <?= $description_json // Cetak data JSON perks sebagai value ?>
             <?= ($i < count($cross_sell_products)) ? ',' : ''; // Tambahkan koma jika bukan item terakhir ?>
         <?php endforeach; ?>
     <?php endif; ?>
 };
</script>

